/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190929;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
public class Ch11_2 {
    public static void main(String[] args) {
       File srcfile = new File("C:\\MyDir\\test.zip");
       File targetfile = new File("C:\\MyDir\\test_copy.zip");
       
       try{
            InputStream fIn =  new FileInputStream(srcfile);
            fIn = new BufferedInputStream(fIn);
            OutputStream fOut = new FileOutputStream(targetfile);
            fOut = new BufferedOutputStream(fOut);
            int data = -1;
            while( (data = fIn.read()) != -1){
                fOut.write(data);
            } 
            fOut.close();
            fIn.close();
       }catch(FileNotFoundException ex){
           System.out.println(ex);
       }catch(IOException ex){
           System.out.println(ex);
       }
     
      
        
        
    }
    
}
