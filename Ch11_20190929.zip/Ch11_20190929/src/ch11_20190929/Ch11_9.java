/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190929;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

/**
 *
 * @author xvpow
 */
public class Ch11_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         File file = new File("C:\\MyDir\\myFile.txt");
   
       try(MyFileReader isr  =new  MyFileReader(file,"big5");  ){
           int data = -1;
                while ((data = isr.read()) != -1){
                    System.out.print((char)data);
                }            
       }catch(FileNotFoundException ex){
           System.out.println(ex);
       }catch(IOException ex){
           System.out.println(ex);
       }
    }
    
}
