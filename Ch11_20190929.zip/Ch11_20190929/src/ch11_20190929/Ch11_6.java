/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190929;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.FileNotFoundException;
public class Ch11_6 {

    public static void main(String[] args) {
       File srcfile = new File("C:\\MyDir\\test.zip");
       File targetfile = new File("C:\\MyDir\\test_copy.zip");
        try(FileInputStream fIn = new FileInputStream(srcfile);
            FileOutputStream fOut = new FileOutputStream(targetfile);    ){
            byte[] buffer = new byte[4056];
            int index = -1;
            while ( (index = fIn.read(buffer))!=-1 ){
                fOut.write(buffer, 0, index);
            }            
        }catch(FileNotFoundException ex){
            
        }catch(IOException ex){
            
        }
        
    }
    
}
