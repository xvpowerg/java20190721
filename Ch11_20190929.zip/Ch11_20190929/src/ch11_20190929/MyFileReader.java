/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190929;

import java.io.File;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.charset.Charset;

public class MyFileReader extends InputStreamReader {
    public MyFileReader(File file,String charset)throws FileNotFoundException{
       super(new FileInputStream(file),Charset.forName(charset)); 
    }
    
     public MyFileReader(File file)throws FileNotFoundException{
         this(file,"utf-8");
    }
    
}
