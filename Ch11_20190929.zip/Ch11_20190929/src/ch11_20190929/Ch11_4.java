/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190929;

/**
 *
 * @author xvpow
 */
public class Ch11_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        try{
           System.out.println("Start....");
           throw new NullPointerException("");
        }catch(NullPointerException ex){
             System.out.println("NullPointerException....");   
        }finally{
            System.out.println("Finall....");
        }
        
        int v1 = 10;
        int v2 = 31;
        
        try{
             System.out.println("Test1...Return Start");
            if (v1 < v2){
                return;
            }
              //System.out.println("Test1...Return End");
        }finally{
              System.out.println("Test1...Return End");
        }
        
        
    }
    
}
