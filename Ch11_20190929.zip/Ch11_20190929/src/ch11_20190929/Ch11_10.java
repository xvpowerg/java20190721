/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190929;
import java.io.File;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
public class Ch11_10 {


    public static void main(String[] args) {
        // TODO code application logic here
       File file= new File("c:\\MyDir\\value.txt"); 
       System.out.println("請輸入想輸出的字串");
       Scanner scan = new Scanner(System.in);
       
       try(FileWriter fw = new FileWriter(file)){
           String msg = scan.nextLine();
           fw.write(msg);
       }catch(IOException ex){
           System.out.println(ex);
       }
        
    }
    
}
