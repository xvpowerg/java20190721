/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190929;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;
public class Ch11_12 {
    public static void main(String[] args)throws Exception {
       File file = new File("C:\\MyDir\\Data.txt");
       ArrayList<Student> list = new ArrayList<>();
        try(FileReader fr = new FileReader(file);
            BufferedReader bfr = new BufferedReader(fr);    ){
            String info = null;
            
            while( (info = bfr.readLine()) != null){
                System.out.println(info);
                String[] stInfos = info.split(",");
                 String name = stInfos[0];
                 Student st = new Student(name);
                 System.out.print(name);
                 for (int i =1;i<stInfos.length;i++){
                     //System.out.print(" 成績:"+stInfos[i]);
                     st.appendScore(Integer.parseInt(stInfos[i]));
                 }
                 list.add(st);
                 System.out.println();
            }            
        }
       list.forEach(st->System.out.println(st));        
    }
    
}
