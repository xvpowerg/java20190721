/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190929;

import java.util.ArrayList;
import java.util.IntSummaryStatistics;
import java.util.List;

/**
 *
 * @author xvpow
 */
public class Student {
    private String name;
    private List<Integer> scoreList = new ArrayList<>();
    private IntSummaryStatistics intSummSta=null;
    public Student(String name){
        this.name = name;
    }
    public void appendScore(int score){
        scoreList.add(score);
        intSummSta = 
         scoreList.stream().mapToInt(sc->sc.intValue()).summaryStatistics();
    }
    public int sum(){
        
        return (int)intSummSta.getSum();
    }
    
    public double avg(){
        return intSummSta.getAverage(); 
    }
    
    public String toString(){
        return this.name+":"+":"+this.sum()+":"+this.avg();
    }
}
