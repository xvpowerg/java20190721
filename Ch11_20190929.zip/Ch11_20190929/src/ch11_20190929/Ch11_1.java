/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190929;

/**
 *
 * @author xvpow
 */
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Ch11_1 {
    //Copy File
    public static void main(String[] args) {
        File file = new File("c:\\MyDir\\myFile.txt");
        File copyFile = new File("c:\\MyDir\\myFile_copy.txt");
        
//        File file = new File("c:\\MyDir\\test.zip");
//        File copyFile = new File("c:\\MyDir\\test_copy.zip");
        try{
              FileInputStream fileIn = new FileInputStream(file);    
              FileOutputStream fileOut = new FileOutputStream(copyFile);
              int data = -1;
              while( (data =fileIn.read() ) != -1  ){
                   //System.out.println(data);
                  fileOut.write(data);
              }
        }catch(FileNotFoundException ex){
            System.out.println(ex);
        }catch(IOException ex){
             System.out.println(ex);
        }
  
        
        
    }
    
}
