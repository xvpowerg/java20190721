/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190908;
import java.util.HashSet;

public class Ch8_1 {
    public static void main(String[] args) {
        //Set 
        //無序
        //重複的元素視為同一元素
       HashSet<Integer> set = new HashSet<>();
        set.add(1);
        set.add(2);
        set.add(9);
        set.add(3);
        set.add(2);   
        
        set.forEach(System.out::println);
       
    }
    
}
