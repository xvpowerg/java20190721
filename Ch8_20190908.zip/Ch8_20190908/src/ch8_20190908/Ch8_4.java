/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190908;
import java.util.TreeSet;
public class Ch8_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Student st1 = new Student("Ken",31);
        Student st2 = new Student("Vivin",26);
        Student st3 = new Student("Join",15);
        Student st4 = new Student("Lindy",83); 
        Student st5 = new Student("Iris",31); 
        
        TreeSet<Student> set = new TreeSet<>();
        set.add(st1);
        set.add(st2);
        set.add(st3);
        set.add(st4);
        set.add(st5);
        set.forEach(System.out::println);
    }
    
}
