/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190908;

import java.util.TreeSet;
import java.util.SortedSet;
/**
 *
 * @author shihhaochiu
 */
public class Ch8_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       TreeSet<Integer> set = new TreeSet<>();
       set.add(5);
       set.add(8);
       set.add(15);
       set.add(20);
        
       SortedSet<Integer> sortSet =  set.subSet(8, 21);
       sortSet.forEach(System.out::println);
        
    }
    
}
