/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190908;

/**
 *
 * @author shihhaochiu
 */
public class Item {
    public enum Location{
        高雄,台中,台北
    }  
    private String name;
    private int price;
    private Location location;
    
    public Item(String name,int price,Location location){
        this.name = name;
        this.price = price;
        this.location = location;
    }
    
    public String getName(){
        return name;
    }
    
    public int getPrice(){
        return price;
    }
    
    public Location getLocation(){
        return location;
    }
    
    public String toString(){
        return name+":"+price+":"+location;
    }
}
