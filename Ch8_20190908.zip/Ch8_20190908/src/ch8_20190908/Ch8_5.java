/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190908;

import java.util.TreeSet;
import java.util.Comparator;
/**
 *
 * @author shihhaochiu
 */
public class Ch8_5 {
    
    private static class MyItemCpmpara implements Comparator<Item>{
            public int compare(Item i1,Item i2){
                if (i1.getPrice() > i2.getPrice()){
                    return 1;
                }else if(i1.getPrice() <i2.getPrice() ){
                    return -1;
                }
                
               int cmp1 =  i1.getName().compareTo(i2.getName()) ;
               if (cmp1 == 0 ){
                    cmp1 = i1.getLocation().compareTo(i2.getLocation());
                }
                return cmp1;
            }
      }
    
    
    public static void main(String[] args) {
        Item i1 = new Item("iPhone7", 25000, Item.Location.台北);
        Item i2 = new Item("iPhone7", 28000, Item.Location.高雄);
        Item i3 = new Item("iPhone8", 29000, Item.Location.台中);
        Item i4 = new Item("iPhone8", 29000, Item.Location.高雄);
        Item i5 = new Item("iPhoneX", 35000, Item.Location.台北);
        Item i6 = new Item("iPhoneX", 32000, Item.Location.台北);
//        MyItemCpmpara myItem = new MyItemCpmpara();
//        TreeSet<Item> t1 = new TreeSet<>(myItem);

// TreeSet<Item> t1 = new TreeSet<>((it1,it2)->{
//       int cmp = it1.getPrice() - it2.getPrice();
//       if (cmp == 0) cmp = it1.getName().compareTo(it2.getName());
//       if (cmp == 0) cmp = it1.getLocation().compareTo(it2.getLocation());
//     return cmp;
//     
// } );
//由大到小
 TreeSet<Item> t1 = new TreeSet<>((it1,it2)->{
       int cmp = it1.getPrice() - it2.getPrice();
       if (cmp == 0) cmp = it1.getName().compareTo(it2.getName());
       if (cmp == 0) cmp = it1.getLocation().compareTo(it2.getLocation());
     return cmp * -1;
     
 } );

//TreeSet<Item> t1 = new TreeSet<>(Comparator.<Item,Integer>comparing((it1)->it1.getPrice()).
//                                 thenComparing((it1)->it1.getName()).
//                                thenComparing((it1)->it1.getLocation()));

//由大到小
//TreeSet<Item> t1 = new TreeSet<>(Comparator.<Item,Integer>comparing((it1)->it1.getPrice()).
//                                 thenComparing((it1)->it1.getName()).
//                                thenComparing((it1)->it1.getLocation()).reversed());
        t1.add(i1);
        t1.add(i2);
        t1.add(i3);
        t1.add(i4);
        t1.add(i5);
        t1.add(i6);
        
        
        t1.forEach(System.out::println);
    }

}
