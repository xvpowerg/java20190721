/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190908;
import java.util.HashSet;
/**
 *
 * @author shihhaochiu
 */
public class Ch8_2 {

  
    public static void main(String[] args) {
       
        Student st1 = new Student("Ken",31);
        Student st2 = new Student("Vivin",26);
        Student st3 = new Student("Join",15);
        Student st4 = new Student("Ken",31);
        HashSet<Student> set =new HashSet<>();
        System.out.println(st1.equals(st4));
        System.out.println(st1.hashCode());
         System.out.println(st4.hashCode());
        set.add(st1);
         set.add(st2);
          set.add(st3);
           set.add(st4);
        set.forEach(System.out::println);
    }
    
}
