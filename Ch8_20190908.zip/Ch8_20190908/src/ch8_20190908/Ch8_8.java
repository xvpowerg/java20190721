/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190908;

import java.util.HashMap;

/**
 *
 * @author shihhaochiu
 */
public class Ch8_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        HashMap<String,Integer> map = new HashMap<>();
        map.put("Ken",100);
        map.put("Vivin",80);
        map.put("Lindy",50);
        map.put("Join",74);
        
        //Key存在
        //Key存在 compute 會執行BIFunction 
        //回傳值 會取代 目前key所對應的value
          map.compute("Ken",(k,v)->{
              System.out.println("Key存在 compute");
              return v+10;
          });
          System.out.println(map);
          System.out.println("============");
           //Key存在 computeIfAbsent 不會執行Function 
          map.computeIfAbsent("Vivin", (key)->{
              System.out.println("Key存在 computeIfAbsent ");
              return 71;});
           System.out.println(map);
              System.out.println("============");
        //Key存在 compute 會執行computeIfPresent
        //回傳值 會取代 目前key所對應的value       
       map.computeIfPresent("Vivin", (key,value)->{
         System.out.println("Key存在 computeIfPresent ");
         return value + 3;
       });
              System.out.println(map);
       //Key不存在
       //Key不存在 回傳值會寫入 Key所對應的value 
      map.compute("Iris",(k,v)->{
              System.out.println("Key不存在 compute");
              return 10;
          });
          System.out.println(map);
            System.out.println("============");
//            //因為v是null所以10 + v 會出錯 原因為v要做自動解封箱
//           map.compute("GiGi",(k,v)->{
//              System.out.println("Key不存在 compute");  
//              return 10 + v;
//          });
        
//        
//           //Key不存在 computeIfAbsent 會執行Function 
          map.computeIfAbsent("GiGi", (key)->{
              System.out.println("Key不存在 computeIfAbsent ");
              return 71;});
           System.out.println(map);           
              System.out.println("============");
//        //Key不存在 compute 不會執行computeIfPresent
//        //回傳值 會取代 目前key所對應的value       
       map.computeIfPresent("Mini", (key,value)->{
         System.out.println("Key不存在 computeIfPresent ");
         return value + 3;
       });
//              System.out.println(map);
        
    }
    
}
