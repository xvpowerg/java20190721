/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190908;
import java.util.HashMap;
import java.util.Set;
import java.util.Map.Entry;
public class Ch8_7 {
    
    public static void main(String[] args) {
       
        HashMap<String,Integer> map = new HashMap<>();
        map.put("Ken",100);
        map.put("Vivin",80);
        map.put("Lindy",50);
        map.put("Join",74);
        map.put("Vivin",41);
        
       // map.forEach((k,v)->System.out.println(k+":"+v));
//       Set<Entry<String,Integer>> entrySet = map.entrySet();
//       
//       for(Entry<String,Integer> entry :entrySet){
//           System.out.println(entry.getKey()+":"+entry.getValue());
//       }
        System.out.println(map.containsKey("Join"));
        System.out.println(map.containsValue(50));
        System.out.println(map.get("Vivin"));
        //map.put("Join", 650);    
        map.putIfAbsent("Join", 650);
        System.out.println(map.get("Join"));
        System.out.println("===========");
//        map.replaceAll(
//                (key,value)->{return value+10;});
//       System.out.println(map.get("Vivin"));
        map.replaceAll((key,value)->value <= 50 ? value + 10: value);
          System.out.println(map.get("Vivin"));
    }
    
}
