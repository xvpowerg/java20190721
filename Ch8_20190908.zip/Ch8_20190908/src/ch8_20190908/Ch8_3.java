/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190908;
import java.util.TreeSet;
public class Ch8_3 {

    
    public static void main(String[] args) {
       TreeSet<Integer> set = new TreeSet<>();
       set.add(90);
       set.add(25);
       set.add(31);
       set.add(74);
       
       set.forEach(System.out::println);
       System.out.println("================");
      System.out.println(set.first());
      System.out.println(set.last()); 
        System.out.println("================");
       System.out.println(set.floor(30)); //<=30
       System.out.println(set.lower(30)); //< 30
        System.out.println("================");
        System.out.println(set.ceiling(30)); //>=30
       System.out.println(set.higher(30)); //>30
       
        System.out.println("================");
       System.out.println(set.floor(25)); //<=25
       System.out.println(set.lower(25)); //< 25
       System.out.println("================");
       System.out.println(set.ceiling(90)); //>=90
       System.out.println(set.higher(90)); //> 90
    }
    
}
