/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190908;

import java.util.HashMap;

/**
 *
 * @author shihhaochiu
 */
public class Ch8_12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        HashMap<String,Integer> map = new HashMap<>();
        map.put("Ken",100);
        map.put("Vivin",80);
        map.put("Lindy",50);
        map.put("Join",74);
        
      
      // int value =  map.get("Iris");//java.lang.NullPointerException
      int value2 = map.getOrDefault("Iris", 0);
      System.out.println(value2);
    }
    
}
