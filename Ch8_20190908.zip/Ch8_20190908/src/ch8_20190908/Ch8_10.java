/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190908;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author shihhaochiu
 */
public class Ch8_10 {
    public static void main(String[] args) {
         Student st1 = new Student("Ken",31);
        Student st2 = new Student("Vivin",26);
        Student st3 = new Student("Join",15);
        Student st4 = new Student("Lindy",83); 
        Student st5 = new Student("Iris",31); 
        Student st6 = new Student("Gigi",27); 
        Student st7 = new Student("BoBo",12);
        Student st8 = new Student("Tian",36); 
        
        //Key Integer  value 字串
        //3  Ken Iris
        //1  Join Bobo
        //2  Vivin Gigi
        ArrayList<Student> list = new ArrayList<>();
        list.add(st1);
        list.add(st2);
        list.add(st3);
        list.add(st4);
        list.add(st5);
        list.add(st6);
        list.add(st7);
        list.add(st8);
        HashMap<Integer,String> map = new HashMap<>();
        
        for (Student st : list){
          int key =   st.getAge() / 10;
          String value = st.getName();
           map.computeIfPresent(key, (k,v)->v +" "+value);
           map.computeIfAbsent(key, (k)->value);
        }
        System.out.println(map);
        
    }
    
}
