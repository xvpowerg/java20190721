/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190915;

/**
 *
 * @author xvpow
 */
public class Ch9_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            MyArrayList lis = new MyArrayList();
            lis.add("Ken");
            lis.add("Vivin");
            lis.add("Lindy");
            lis.add("Tom");
            lis.add("Lucy");
            lis.add("Gary");
            lis.foreach(System.out::println);
            
           
              MyArrayList<Integer> lis2 = new MyArrayList<>();
              lis2.add(10);
              lis2.add(5);
              lis2.add(1);
              lis2.add(7);
              lis2.foreach(System.out::println);
              
          StudentList<Student> stList = new StudentList<>();
              
    }
    
}
