/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190915;

import java.util.function.Consumer;
import java.util.Arrays;
/**
 *
 * @author xvpow
 */
public class MyArrayList<T> {
    private int defLen = 5;
    private int arrayLen = defLen;
    private int currentIndex = -1;
    private Object[] base = new Object[arrayLen];
    
    public void add(T value){
        if (currentIndex + 1 == arrayLen){
             arrayLen*=2;        
             base = Arrays.copyOf(base, arrayLen);              
        }
        base[++currentIndex] = value;
    }
    
    public T get(int index){
        return (T)base[index];
    }
    
    public int size(){
        return currentIndex+1;
    }
    public void foreach(Consumer<T> consum){
        for (int i = 0; i <= currentIndex;i++){
            consum.accept((T)base[i]);
        }
    }
}
