/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190915;
import java.util.TreeMap;
import java.util.Comparator;
public class Ch9_4 {

   
    public static void main(String[] args) {
        Item i1 = new Item(100,"Item0",5.6f);
        Item i2 = new Item(101,"Item1",7.1f);
        Item i3 = new Item(102,"Item2",3.8f);        
        Item i4 = new Item(101,"Item3",7.1f);
        Item i5 = new Item(102,"Item4",3.8f);
        Item i6 = new Item(101,"Item5",7.1f);
        Comparator<Item> cmp = Comparator.<Item,Integer>comparing((it)->it.getId()).
                thenComparing((it)->it.getName());
        TreeMap<Item,Float> map = new TreeMap<>(cmp);
        map.put(i1, i1.getPrice());
        map.put(i2, i2.getPrice());
        map.put(i3, i3.getPrice());
        map.put(i4, i4.getPrice());
        map.put(i5, i5.getPrice());
        map.put(i6, i6.getPrice());
        map.forEach((k,v)->System.out.println(k+":"+v));
    }
    
}
