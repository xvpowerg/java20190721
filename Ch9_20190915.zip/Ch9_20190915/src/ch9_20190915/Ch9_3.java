/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190915;
import java.util.TreeMap;
import java.util.Map.Entry;
public class Ch9_3 {
    public static void main(String[] args) {
       TreeMap<Integer,String> treeMap = new TreeMap<>();
        treeMap.put(5, "Ken");
        treeMap.put(2, "Viivn");
        treeMap.put(1, "Lindy");
        treeMap.put(3, "Join");
        treeMap.put(4, "Tom");        
        treeMap.forEach((k,v)->System.out.println(k+":"+v));
        //========================================
       Entry<Integer,String> entry =  treeMap.ceilingEntry(2);
        int key =  treeMap.ceilingKey(2);        
        System.out.println(entry);
        System.out.println(key);
        
        System.out.println(treeMap.higherEntry(4));        
        System.out.println(treeMap.floorEntry(2));
        System.out.println(treeMap.lowerEntry(2));
        
        treeMap.merge(3, "Iris", (oldV,newV)->{                                       
                                    return oldV+":"+newV;});
        System.out.println(treeMap);
        
        treeMap.merge(6, "William", (oldV,newV)-> oldV+":"+newV);
         System.out.println(treeMap);
    }
    
}
