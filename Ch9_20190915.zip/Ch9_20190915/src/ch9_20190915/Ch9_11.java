/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190915;

import java.util.stream.Stream;

/**
 *
 * @author xvpow
 */
public class Ch9_11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Item i1 = new Item(100,"Item0",5.6f);
        Item i2 = new Item(101,"Item1",7.1f);
        Item i3 = new Item(102,"Item2",3.8f);        
        Item i4 = new Item(103,"Item3",9.1f);
        Item i5 = new Item(104,"Item4",8.8f);      
        Stream<Item> stream = Stream.of(i1,i2,i3,i4,i5);
        stream.filter((item)->item.getId() > 101).forEach(System.out::println);
    }
    
}
