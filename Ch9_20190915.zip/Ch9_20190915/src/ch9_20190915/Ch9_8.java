/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190915;
import java.util.stream.Stream;
import java.util.Random;
import java.util.stream.IntStream;

public class Ch9_8 {
    private static Item genItem(){
        Random radnom = new Random();
        int id = radnom.nextInt(10000);
        String name = "Item:"+id;
        float price = radnom.nextFloat();
        Item item = new Item(id,name,price);
        return item;
    }
    public static String mageStr(String str){
        Random ran = new Random();
        char value = (char) (ran.nextInt(26)+'A');
        return str + value;
    }
    
    public static void main(String[] args) {
            Stream<String> st1 = Stream.of("A","B","C","D");            
            st1.forEach(System.out::println);
            Random rand = new Random();
            int[] valus = new int[100];
            for (int i =1;i<=100;i++){
                valus[i-1] = rand.nextInt();
            }
           IntStream intStream = IntStream.of(valus);
           intStream.forEach(System.out::println);
        System.out.println("=================");
        
        Stream<Item> strItem =   Stream.generate(Ch9_8::genItem);
        //strItem.limit(10).forEach(System.out::println);
     Stream<String> stream=   Stream.iterate("Title:", Ch9_8::mageStr);
    // stream.limit(10).forEach(System.out::println);
     
     //IntStream.range(1, 10).forEach(System.out::println);
     IntStream.rangeClosed(1, 10).forEach(System.out::println);
    }
    
}
