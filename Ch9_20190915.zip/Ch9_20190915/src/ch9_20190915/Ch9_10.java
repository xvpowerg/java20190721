/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190915;

import java.util.stream.Stream;

/**
 *
 * @author xvpow
 */
public class Ch9_10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Stream<String>  stream = Stream.of("Vivin","Lindy","Ken","Join","William","Lucy");
//        boolean b1 = stream.allMatch((name)->name.length() >2);
//        System.out.println(b1);        
//       boolean b2 = stream.allMatch((name)->name.endsWith("n"));
//       System.out.println(b2);

//        boolean b3 = stream.anyMatch((name)->name.endsWith("y"));
//        System.out.println(b3);
//        boolean b4 = stream.anyMatch((name)->name.startsWith("H"));
//        System.out.println(b4);
//       boolean b5 =  stream.noneMatch((name)->name.isEmpty());
//       System.out.println(b5);
//        boolean b6 = stream.noneMatch((name)->name.startsWith("J"));
//        System.out.println(b6);
        //allMatch碰到不成立地條件時 就不繼續檢查
//        boolean b7 = 
//                  stream.peek(System.out::println).allMatch((n)->n.length() >=3);
//          boolean b7 = 
//                  stream.peek(System.out::println).allMatch((n)->n.length() >3);
          //anyMatch 只要條件成立不繼續
          //  stream.peek(System.out::println).anyMatch((n)->n.length() < 2);stream.peek(System.out::println).anyMatch((n)->n.length() < 2);
//           boolean b8 = stream.peek(System.out::println).anyMatch((n)->n.length() >= 4);
//            System.out.println(b8);
           boolean b9 = stream.peek(System.out::println).noneMatch((n)->n.length() >=4);
           System.out.println(b9);
           
    }
    
}
