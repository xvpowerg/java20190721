/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190915;

/**
 *
 * @author xvpow
 */
public class Student implements Comparable<Student> {
    private String name;
    private int  age;
    
    
    //目前的age大於傳入的age回傳正數
     //目前的age小於傳入的age回傳負數
     //目前的age等於傳入的age回傳0
    public int compareTo(Student st){
        if (age > st.age){
            return 1;
        }else if(age < st.age){
            return -1;
        }
        return name.compareTo(st.name);
    }
    
    public boolean equals(Object obj){
        if (obj == null || obj instanceof Student == false){
            return false;
        }
        Student tmp = (Student)obj;
        return name.equals(tmp.name) && age == tmp.age;
    }
    
//    public int hashCode(){
//        return name.hashCode() + age;
//    }
    public Student(String name,int age){
        this.name = name;
        this.age = age;
    }
    
    public String getName(){
        return name;
    }
    public int getAge(){
        return age;
    }
    
    public String toString(){
        return name+":"+age;
    }
    
}