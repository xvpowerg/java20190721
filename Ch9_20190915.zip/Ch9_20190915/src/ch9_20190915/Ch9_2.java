/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190915;
import java.util.HashMap;
import java.util.ArrayList;
public class Ch9_2 {

    public static void main(String[] args) {
            
        HashMap<Item,Integer> map1 = new HashMap<>();
        //{100:Item0:5.6 :1 , 101:Item1:7.1:3, 102:"Item2":3.8 :2 }
        Item i1 = new Item(100,"Item0",5.6f);
        Item i2 = new Item(101,"Item1",7.1f);
        Item i3 = new Item(102,"Item2",3.8f);        
        Item i4 = new Item(101,"Item1",7.1f);
        Item i5 = new Item(102,"Item2",3.8f);
        Item i6 = new Item(101,"Item1",7.1f);
        System.out.println(i2.equals(i4));
         System.out.println(i2.hashCode());
            System.out.println(i4.hashCode());
        ArrayList<Item> list = new ArrayList<>();
        list.add(i1);
        list.add(i2);
        list.add(i3);
        list.add(i4);
        list.add(i5);
        list.add(i6);
         for (Item key : list){
             map1.computeIfPresent(key, 
                     (oldKey,value)-> value +1);
             map1.computeIfAbsent(key, (oldkey)->1);             
         }
        System.out.println(map1);  
        
//        for (Item key : list){
//            int count = 0;
//             if (map1.containsKey(key)) {
//                 count = map1.get(key) +1;
//             }else{
//                 count = 1;
//             }
//             map1.put(key, count);
//        }
//        System.out.println(map1);
      
        
        
        
    }
    
}

