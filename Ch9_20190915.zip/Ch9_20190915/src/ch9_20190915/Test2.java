/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190915;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.function.Supplier;
public class Test2 extends Test1 {
    private int base = 10;
    private int[] array = {6,7,8,9};
    public <T> T calculate(T v1,T v2,BinaryOperator<T> bo){                     
           System.out.println(base);
        return   bo.apply(v1, v2);
    }
    
    public  <T extends List>  T collect(Supplier<T> su){
       T list =  su.get();
       for (int v :array){
          list.add(v);
       }
        return list;
    } 
}
