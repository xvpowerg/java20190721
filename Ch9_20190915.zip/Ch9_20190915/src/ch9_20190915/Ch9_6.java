/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190915;
import java.util.ArrayList;
public class Ch9_6 {
    public static void printList(ArrayList<Test2> list){
        
    }
    //? extends 只可 讀取不可寫入
    public static void printList2(ArrayList<? extends Test2> list){
      Test2 t2 =  list.get(0);
      //list.add(new Test2());
    }
    
    static void printList3(ArrayList<? super Test2> list){
       Test1 t2 =  (Test1)list.get(0);
       list.add(new Test2());
       list.add(new Test3());
    }
    public static void main(String[] args) {
       //ArrayList<Test2> list = new ArrayList<Test2>();
        ArrayList<Test2> list2=  new ArrayList<Test2>();
        printList(list2);
         ArrayList<Test3> list3=  new ArrayList<Test3>();
         list3.add(new Test3());
        printList2(list3);
        
        
         ArrayList<Test1> list1=  new ArrayList<Test1>();
         printList3(list2);
         printList3(list1);
        
    }
    
}
