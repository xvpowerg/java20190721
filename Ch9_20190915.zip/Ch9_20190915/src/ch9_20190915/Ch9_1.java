/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190915;
import java.util.TreeSet;
import java.util.Comparator;
/**
 *
 * @author xvpow
 */
public class Ch9_1 {
    private static class DescOrder implements Comparator<Student>{
            public int compare(Student st1,Student st2){
                 int orderIndext =  st2.getAge() - st1.getAge();
                 if (orderIndext ==0) orderIndext = st2.getName().compareTo(st1.getName());
                return orderIndext;
            }
    }
    public static void main(String[] args) {
        Student st1 = new Student("Ken",31);
        Student st2 = new Student("Vivin",26);
        Student st3 = new Student("Join",15);
        Student st4 = new Student("Lindy",83); 
        Student st5 = new Student("Iris",31); 
        Student st6 = new Student("Gigi",27); 
        Student st7 = new Student("BoBo",12);
        Student st8 = new Student("Tian",36); 
        
        Comparator<Student> descOrder2 = Comparator.
                <Student,Integer>comparing((st)->st.getAge()).
                thenComparing((st)->st.getName()).reversed();
        DescOrder descOrdr = new DescOrder();
        //TreeSet<Student> set = new TreeSet<>(descOrdr);
         TreeSet<Student> set = new TreeSet<>(descOrder2);
        set.add(st1);
        set.add(st2);
        set.add(st3);
        set.add(st4);
        set.add(st5);
        set.add(st6);
        set.add(st7);
        set.add(st8);
        set.forEach(System.out::println);
        
        
        
    }
    
}
