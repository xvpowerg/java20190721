/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190915;
import java.util.ArrayList;
import java.util.function.Consumer;
/**
 *
 * @author xvpow
 */
public class StudentList<T extends Student> {
    private ArrayList<T> list = new ArrayList<>();
    
    public void add(T v){
        list.add(v);
    }
    
    public T get(int index){
        return list.get(index);
    }
    
    public void foreache(Consumer<T> consumer){
        list.forEach(consumer);
    }
    
    
}
