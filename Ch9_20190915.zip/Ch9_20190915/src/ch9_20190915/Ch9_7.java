/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190915;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;

/**
 *
 * @author xvpow
 */
public class Ch9_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Test2 t2 = new Test2();
       int sum =  t2.calculate(20, 10, (v1,v2)->v1+v2);
       System.out.println(sum);
        float value = t2.<Float>calculate(2.5f, 1.5f, (v1,v2)->v1 * v2);
        System.out.println(value);
           System.out.println("=============");
        LinkedList<Integer> list = t2.collect(LinkedList::new);
        for (int v : list){
            System.out.println(v);
        }
    }
    
}
