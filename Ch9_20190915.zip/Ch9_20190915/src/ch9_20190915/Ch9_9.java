/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190915;

import java.util.ArrayList;
import java.util.stream.Stream;

/**
 *
 * @author xvpow
 */
public class Ch9_9 {


    public static void main(String[] args) {
     
        //Stream 特性
        //1 不可重複使用
        //2 有Lazy 與 Terminal
        //3 不會改改變來源
       Stream<String>  str = Stream.of("Ken","Vivin","Lindy","Join","William","Lucy");
       //str.filter((name)->name.length() > 4).forEach(System.out::println);
       str.peek((name)->System.out.println("Filter之前"+name)).
               filter((name)->name.length() >4).
               peek((name)->System.out.println("Filter之後"+name)).
               forEach(System.out::println);
       
       ArrayList<String> list2 = new ArrayList<>();
       list2.add("Gigi");
       list2.add("Kevn");
       list2.add("Len");
       list2.stream().filter(n->n.length() > 3).forEach(System.out::println);
        System.out.println(list2.size());
    }
    
}
