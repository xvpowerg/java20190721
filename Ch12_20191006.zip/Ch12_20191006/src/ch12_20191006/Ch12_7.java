/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191006;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class Ch12_7 {

    public static void main(String[] args) throws Exception{
     Student st1 = new Student("Ken",27,181);
     st1.setBook(new Book("ISBN101110","java"));
     System.out.println(st1);
     File file = new File("c:\\mydir\\student.obj");
        try(FileOutputStream fout = new FileOutputStream(file);
            ObjectOutputStream objOut = new  ObjectOutputStream(fout)   ){
                objOut.writeObject(st1);
        }
    }
    
}
