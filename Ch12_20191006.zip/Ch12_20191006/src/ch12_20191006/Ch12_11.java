/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191006;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
/**
 *
 * @author xvpow
 */
public class Ch12_11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws Exception {
        Path path1 =   Paths.get("C:\\MyDir\\msg.txt");
       Path path2 =   Paths.get("C:\\MyDir\\Dir2\\msg_move.txt");       
      // Files.move(path1, path2,StandardCopyOption.ATOMIC_MOVE);
        Path path3 =   Paths.get("C:\\MyDir\\msg2.txt");
     //   Files.delete(path3);
       boolean b2 =  Files.deleteIfExists(path3);
       System.out.println(b2);
       
       Path path4 =   Paths.get("C:\\MyDir\\msg9.txt");
       Path path5 =   Paths.get("C:\\MyDir\\msg9.txt");
       boolean isSameFile = Files.isSameFile(path5, path4);
       System.out.println(isSameFile);
          
        path4 =   Paths.get("C:\\MyDir\\.\\msg9.txt");
        path5 =   Paths.get("C:\\MyDir\\msg9.txt");
       boolean isSameFile2 = Files.isSameFile(path5, path4);
       System.out.println(isSameFile2);
    }
    
}
