/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191006;
import java.io.IOException;
/**
 *
 * @author xvpow
 */
public class Ch12_1 {
    public static void main(String[] args) {      
     try(ConnectionNet connNet = new ConnectionNet("192.168.1.2");){
         connNet.connection();
     }catch(IOException ex){
         System.out.println(ex);
     }
     
//     try{
//           connNet.connection();          
//     }finally{
//         try{
//            connNet.close();    
//         }catch(IOException ex){
//                 System.out.println(ex);
//           }         
//     }
 
        
        
        
    }    
}
