/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191006;
import java.time.LocalDateTime;
import java.io.Serializable;
/**
 *
 * @author xvpow
 */
public class Book implements Serializable{
    private String isbn;
    private String bookName;
    private transient LocalDateTime time;
    public Book(String isbn,
            String bookName){
       this.isbn = isbn;
       this.bookName = bookName;
       this.time = LocalDateTime.now();        
    }
    public void setTime(LocalDateTime time){
        this.time = time;
    }
    public String toString(){
        return bookName+":"+isbn+":"+this.time;
    }
}
