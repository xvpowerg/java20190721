/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191006;

import java.io.IOException;

/**
 *
 * @author xvpow
 */
public class Ch12_2 {

    public static void main(String[] args) {
      
      
//      try(TestClose t1 = new TestClose("T1",false);
//          TestClose t2 = new TestClose("T2",false);){
//          System.out.println("Body.....");
//      }catch(IOException ex){
//          System.out.println(ex);
//      }finally{
//        System.out.println("finally.....");
//      }

//       try(TestClose t1 = new TestClose("T1",false);
//          TestClose t2 = new TestClose("T2",true);){
//          System.out.println("Body.....");
//      }catch(IOException ex){
//          System.out.println(ex);
//      }finally{
//        System.out.println("finally.....");
//      }

//    try(TestClose t1 = new TestClose("T1",false);
//          TestClose t2 = new TestClose("T2",true);){
//        System.out.println("Body....");
//        throw new IOException("Body Exception");
//      }catch(IOException ex){
//          System.out.println(ex);
//      }finally{
//        System.out.println("finally.....");
//      }
        
     try(TestClose t1 = new TestClose("T1",false);
          TestClose t2 = new TestClose("T2",true);){
        System.out.println("Body....");
        throw new IOException("Body Exception");
      }catch(IOException ex){
         Throwable[] ths =   ex.getSuppressed();
         System.out.println(ex);
         for (Throwable th : ths){
                 System.out.println(th.toString());
         }   
      }finally{
        System.out.println("finally.....");
      }


        
    }
    
}
