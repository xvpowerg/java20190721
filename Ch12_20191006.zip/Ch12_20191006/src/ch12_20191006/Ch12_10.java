/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191006;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
public class Ch12_10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Path path1 =   Paths.get("C:\\MyDir\\test.zip");
      Path path2 =   Paths.get("C:\\MyDir\\test_copy.zip");
      boolean b1 = Files.exists(path1);
      System.out.println(b1);
      //預設情況下 Files.copy　不允許重複
      
      try{
           Files.copy(path1, path2,StandardCopyOption.REPLACE_EXISTING,
                   StandardCopyOption.COPY_ATTRIBUTES);    
      }catch(IOException ex){
          System.out.println(ex);
      }
      
      
    }
    
}
