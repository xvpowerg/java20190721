/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191006;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author xvpow
 */
public class Ch12_8 {
    public static void main(String[] args)throws Exception {
      File file = new File("c:\\mydir\\student.obj");
        try(FileInputStream fout = new FileInputStream(file);
            ObjectInputStream objOut = new  ObjectInputStream(fout)   ){
               Student st = (Student) objOut.readObject();
               System.out.println(st);
        }
    }
    
}
