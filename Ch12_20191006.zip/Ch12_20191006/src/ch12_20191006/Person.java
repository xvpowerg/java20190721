/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191006;

import java.io.Serializable;

/**
 *
 * @author xvpow
 */
public class Person implements Serializable{
    private String name;
    private int age;
    private int height;
    public Person(){
        
    }
    public Person(String name,int age,int height){
        this.name = name;
        this.height = height;
        this.age = age;
    }
    
     public String toString(){
        return name+":"+age+":"+height;
    }
}
