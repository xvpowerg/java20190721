/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191006;
import java.io.IOException;
import java.io.Serializable;
import java.time.LocalDateTime;
public class Student extends Person implements Serializable{
    private static final long serialVersionUID = 12312809L;
    private Book book;
    public Student(String name,int age,int height){
        super(name,age,height);
//        this.name = name;
//        this.age = age;
    }
    
    public void setBook(Book book){
        this.book = book;
    }
    
    public String toString(){
        return super.toString()+":"+book;
    }
    //可參與序列化過程
    private void writeObject(java.io.ObjectOutputStream out) throws IOException{
        out.defaultWriteObject();
        System.out.println("writeObject.....");
    }
    private void readObject(java.io.ObjectInputStream in) throws IOException,
            ClassNotFoundException{
         in.defaultReadObject();
        System.out.println("readObject....." ); 
        this.book.setTime(LocalDateTime.now());
    }
}
