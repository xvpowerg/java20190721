/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191006;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
public class Ch12_3 {
    public static void main(String[] args) {
     //序列就是把物件變檔案
      File file = new File("c:\\MyDir\\MyObj.obj");
      String name = "Ken";
      try(FileOutputStream fout = new FileOutputStream(file);
         ObjectOutputStream oos = new ObjectOutputStream(fout)){
          oos.writeObject(name);
      }catch(IOException ex){
          System.out.println(ex);
      }    
        
    }
    
}
