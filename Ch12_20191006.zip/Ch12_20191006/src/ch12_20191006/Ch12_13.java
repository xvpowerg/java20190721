/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191006;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.util.stream.Stream;
public class Ch12_13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws Exception {
        Path path2 = Paths.get("C:","MyDir");
        Stream<Path> st = Files.list(path2);
       // st.forEach(System.out::println);
        //Integer.MAX_VALUE
        Stream<Path> st2 = Files.walk(path2, 3);
        st2.forEach(System.out::println);
    }
    
}
