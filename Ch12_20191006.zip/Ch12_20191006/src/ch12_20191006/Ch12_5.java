/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191006;
import java.util.HashMap;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
public class Ch12_5 {
    
    
    public static void main(String[] args) {               
        //A-Z 英文字母 作為一個Map的Key
        //每一個Key 可隨機對映到一個數字（1~10000）
        //myObj1.obj --> 反序列化後　可取得一個Map
        //Map.get("A")
        IntStream intStr = IntStream.rangeClosed(0, 25);
      Map<String,Integer> map = 
              intStr.mapToObj((i)->  
                String.valueOf( (char)(i+'A') )).
                     collect(Collectors.toMap((key)->key, 
                      (v)-> new Random().nextInt(10000) + 1));
        System.out.println(map);
        File file = new File("c:\\MyDir\\myMap.obj");
        try(FileOutputStream fOut = new FileOutputStream(file);
            ObjectOutputStream ibjOut = new ObjectOutputStream(fOut);){
            ibjOut.writeObject(map);
        }catch(IOException ex){
            System.out.println(ex);
        }
        
    }
    
}
