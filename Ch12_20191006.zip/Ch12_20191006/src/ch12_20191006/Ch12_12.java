/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191006;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.util.IntSummaryStatistics;
import java.util.List;
/**
 *
 * @author xvpow
 */
public class Ch12_12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws Exception {
       /* Path path = Paths.get("C:","MyDir","myFile.txt");
         List<String> values =  Files.readAllLines(path);
         values.forEach(System.out::println);*/
       
         Path path2 = Paths.get("C:","MyDir","values.txt");
         List<String> valueList = Files.readAllLines(path2);
        IntSummaryStatistics is =   valueList.stream().
                mapToInt(str->Integer.parseInt(str)).
                 summaryStatistics();
        System.out.printf("sum:%d Avg:%.2f %n",is.getSum(),is.getAverage());
    }
    
}
