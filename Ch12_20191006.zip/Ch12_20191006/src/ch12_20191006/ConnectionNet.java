/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191006;
import java.io.IOException;
public class ConnectionNet implements AutoCloseable {
    private String ip;
    private StatusType statusType;
    enum StatusType{
        NONE,
        CLOSEING,
        CONNECTIONING
    }
    public ConnectionNet(String ip){
        this.ip = ip;
        this.statusType = StatusType.NONE;
    }
    public void connection(){
            if (this.statusType != StatusType.CONNECTIONING){
                    System.out.println("開始連線"+ip);
            }else{
                    System.out.println("已連線"+ip);
            }      
    }
    public void close()throws IOException{
            if (this.statusType == StatusType.CONNECTIONING){
                System.out.println("關閉連線!:"+ip);
            }else{
                System.out.println("已關閉連線!:"+ip);
            }        
        }
}
