/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191006;

import java.io.IOException;

/**
 *
 * @author xvpow
 */
public class TestClose implements AutoCloseable {
    private String  msg;
    private boolean throwException = false;
    TestClose(String  msg,boolean throwException){
        this.msg = msg;
        this.throwException = throwException;
    }
    @Override
    public void close() throws IOException {
         System.out.println(msg);        
        if (throwException){
            throw new IOException("by "+msg+" Excetpion");
        }
       
    }
    
}
