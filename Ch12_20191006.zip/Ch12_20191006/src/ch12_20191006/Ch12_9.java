/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191006;
import java.nio.file.Path;
import java.nio.file.Paths;
public class Ch12_9 {

    public static void main(String[] args) {
      Path p1 =  Paths.get("C:\\MyDir","A","B","myFile.txt");
       System.out.println(p1.getFileName());
       System.out.println(p1.getParent());
       System.out.println(p1.getRoot());   
       System.out.println(p1.getNameCount());   
       
       System.out.println(p1.subpath(0, 3));   
       
       Path p2 = Paths.get("C:","MyDir","..","MyDir","MyDir2");
       System.out.println(p2);
       System.out.println(p2.normalize());
       
       Path p3 = Paths.get("C:","MyDir","MyDir2");
       Path p4 = Paths.get("MyFile.txt");
       Path p5 = p3.resolve(p4);
       System.out.println(p5);
       
      Path p6 = Paths.get("C:","MyDir","MyDir2");
      Path p7 = Paths.get("c:","MyFile.txt");
      Path p8 = p6.resolve(p7);
      System.out.println(p8);  
      
     Path p9 = Paths.get("C:","MyDir","MyDir2");
     Path p10 = Paths.get("c:","MyFile.txt");  
    Path p11 = p9.relativize(p10);
    System.out.println(p11);
     Path p12 = Paths.get("C:","MyDir","MyDir2");
     Path p13 = Paths.get("d:","MyFile.txt");  
       Path p14 = p12.relativize(p13);
    
    }
    
}
