/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20191013;

/**
 *
 * @author xvpow
 */
public class Ch13_5 {
  static  class TestLock{
      public  synchronized  void test1(TestLock lock){
          System.out.println("in test1");
          lock.test2();
      }
      
      public synchronized void test2(){
          System.out.println("Test2 Pass:"+Thread.currentThread().getName());
      }
  }
    
    
    public static void main(String[] args) {
        TestLock Lock1 = new TestLock();
        TestLock Lock2 = new TestLock();
        
        Thread t1 = new Thread(()->Lock1.test1(Lock2));
        
        Thread t2 = new Thread(()->Lock2.test1(Lock1));
        t1 .start();
        t2.start();
        
        
    }
    
}
