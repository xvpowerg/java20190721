/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20191013;

/**
 *
 * @author xvpow
 */
public class Ch13_3 {
    
    static class Test1{
        private  int value;
//        public synchronized void loop(){
//            for (int i =1;i<=3;i++){
//                System.out.println("Th1:"+Thread.currentThread().getName());
//            }
//             
//            for (int i =1;i<=5;i++){              
//                value++;
//                System.out.println(value);
//               System.out.println("Th2:"+Thread.currentThread().getName());
//            }          
//        }
        
        
         public  void loop(){
             
            for (int i =1;i<=3;i++){
                System.out.println("不需要鎖:"+Thread.currentThread().getName());
                try{Thread.sleep(200);}catch(InterruptedException ex){}
            }
             
            
           synchronized(this){
                 for (int i =1;i<=5;i++){              
                    value++;
                    System.out.println(value);
                   System.out.println("需要鎖:"+Thread.currentThread().getName());
                }   
               
           } 
  
            
        }
    }
  
    public static void main(String[] args) {
       Test1 t1 = new Test1();
       Thread th1 = new Thread(()->{
             t1.loop();       
       });
      
       Thread th2 = new Thread(()->{
            t1.loop();
       });
       
       th1.start();
       th2.start();
    }
    
}
