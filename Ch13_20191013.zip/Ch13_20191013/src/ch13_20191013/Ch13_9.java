/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20191013;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author xvpow
 */
public class Ch13_9 {

    static void insertData( Statement stm,String name,float s1,float s2,float s3)throws Exception{
        java.util.Random ran = new  java.util.Random ();
        int id = ran.nextInt(100000)+300;
        String sql = String.format("INSERT INTO Student(id,st_name,score1,score2,score3)"
                + " VALUES(%d,'%s',%.2f,%.2f,%.2f)", id,name,s1,s2,s3);
        System.out.println(sql);
        stm.executeUpdate(sql);
    }
    public static void main(String[] args)throws Exception{
    String url = "jdbc:derby://localhost:1527/mydb";
        String user = "qwer";
        String pwd = "qwer";
        
        
          try(Connection conn= DriverManager.getConnection(url, user, pwd);
          Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                     ResultSet.CONCUR_UPDATABLE) ){
           conn.setAutoCommit(false);
            insertData(stm,"A1",100,80,71);  
            insertData(stm,"B1",100,80,71); 
            
            if (true){
                throw new Exception("Erro!!");
            }
            insertData(stm,"C1",100,80,71);  
           conn.commit();
            
          }
    }
    
}
