/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20191013;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
public class Ch13_7 {

    public static void main(String[] args) {
         String url = "jdbc:derby://localhost:1527/mydb";
        String user = "qwer";
        String pwd = "qwer";
        Scanner scaner = new Scanner(System.in);
       try(Connection conn= DriverManager.getConnection(url, user, pwd);
          Statement stm = conn.createStatement() ){
           System.out.println("請輸入ID:");
           String condition = scaner.next();
          ResultSet res =  stm.executeQuery("SELECT * FROM STUDENT WHERE ID="+condition);
          boolean next = false;
           res.absolute(1);
          while( res.next()){
              next = true;
             /* int id =res.getInt(1);
              String name = res.getString(2);
              float s1 = res.getFloat(3);
              float s2 =  res.getFloat(4);
              float s3 =  res.getFloat(5);
              System.out.printf("%d %s %.2f %.2f %.2f %n",id,name,s1,s2,s3);*/
             int id = res.getInt("ID");
             String name = res.getString("ST_NAME");
             float s1 = res.getFloat("score1");
             float s2 = res.getFloat("score2");
             float s3 = res.getFloat("score3");
                System.out.printf("%d %s %.2f %.2f %.2f %n",id,name,s1,s2,s3);
               
          }
          if (!next ){
              System.out.println("找不到!!");
          }
       } catch(SQLException ex){
           System.out.println(ex);
       }
        
        
        
        
    }
    
}
