/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20191013;

/**
 *
 * @author xvpow
 */
public class Ch13_4 {
    static class Test2{
        static int count  = 0;
        static void loop(){
            synchronized(Test2.class){
                    for (int i =1;i<=5;i++){
                     count++;
                     System.out.println(count);
                 } 
            }            
        }
    }
    
    
    public static void main(String[] args) {
      Thread t1 = new Thread(()->{
           Test2.loop();
      });
   
         Thread t2 = new Thread(()->{
           Test2.loop();
      });
         
         t1.start();
         t2.start();
    }
    
}
