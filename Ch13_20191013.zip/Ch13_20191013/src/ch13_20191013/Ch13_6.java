/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20191013;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.Scanner;
public class Ch13_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String url = "jdbc:derby://localhost:1527/mydb";
        String user = "qwer";
        String pwd = "qwer";
        Connection conn =  null;
          Statement st = null;
          
        try{
          conn =    DriverManager.getConnection(url, user, pwd);
           st = conn.createStatement();
           Scanner scn = new Scanner(System.in);
           System.out.println("請輸入ID:");
           int id = scn.nextInt();
           System.out.println("請輸入Name:");
           String name =scn.next();
           System.out.println("請輸入成績1:");
           String score1 =scn.next();
           System.out.println("請輸入成績2:");
           String score2 =scn.next();
           System.out.println("請輸入成績3:");
           String score3 =scn.next();
           
          st.executeUpdate("INSERT INTO STUDENT "
                  + "(ID,ST_NAME,SCORE1,SCORE2,SCORE3) "
                  + " VALUES("+id+  ",'"+name+"',"+score1+","+score2+","+score3+") ");
        }catch(SQLException ex){
            System.out.println(ex);
        }finally{
            try{
                  st.close();
                  conn.close();
                  
            }catch(Exception ex){
                
            }
          
        }
       
        
    }
    
}

