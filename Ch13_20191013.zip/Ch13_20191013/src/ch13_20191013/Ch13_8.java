/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20191013;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Ch13_8 {

    static void printResultSet(ResultSet res)throws Exception{
        int id = res.getInt("ID");
          String name = res.getString("st_name");
          System.out.println(id+":"+name);
    }
    public static void main(String[] args)throws Exception {
    String url = "jdbc:derby://localhost:1527/mydb";
        String user = "qwer";
        String pwd = "qwer";
          try(Connection conn= DriverManager.getConnection(url, user, pwd);
          Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                     ResultSet.CONCUR_UPDATABLE) ){
          ResultSet res =  stm.executeQuery("SELECT * FROM STUDENT");
          res.absolute(2);
          printResultSet(res);
           res.absolute(-2);
          printResultSet(res);
       System.out.println("=====relative=====");
         res.beforeFirst();
       res.relative(1);
       printResultSet(res);   
        res.relative(2);
       printResultSet(res);  
       res.relative(-1);
         printResultSet(res);  
       //res.relative(-5);   //會出現例外
       // printResultSet(res);  
          }
    }
    
}
