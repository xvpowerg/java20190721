/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20191013;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoField;
public class Ch13_1 {

  
    public static void main(String[] args) {
        //localTime 的方法都不會改變來源
      /* LocalTime localTime =  LocalTime.of(10, 25);
       System.out.println(localTime);
       
     LocalTime newLocalTime = localTime.plusMinutes(60);
       System.out.println(newLocalTime);
       
      System.out.println(localTime.isAfter(newLocalTime));
      System.out.println(localTime.isBefore(newLocalTime));*/
      LocalDate localDate = LocalDate.of(2019, 10, 31);
      System.out.println(localDate);
      LocalDate newLocalDate = localDate.plusDays(20);
      System.out.println(newLocalDate);
      
      LocalDateTime localDateTime = LocalDateTime.of(2018, 9,23, 13, 52);
      System.out.println(localDateTime);
      System.out.println(localDateTime.getMinute());
     
      System.out.println(localDateTime.get(ChronoField.MONTH_OF_YEAR));
        
        //System.out.println(newLocalDate.get(ChronoField.SECOND_OF_DAY));   
      LocalTime localTime2 =  LocalTime.of(10, 25); 
      System.out.println(localTime2.get(ChronoField.MINUTE_OF_HOUR));   
      //System.out.println(localTime2.get(ChronoField.DAY_OF_YEAR));      
    }
    
}
