/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190901;

/**
 *
 * @author shihhaochiu
 */
public class Ch7_1 {
    private String outValue = "test Out";
    private static String outStaticValue="test static out";
    //static class 只能讀取static 的外部類屬性
    private static class StaticInnerClass{
        private int value;
        
        public void setValue(int value){
            this.value = value;
        }
        public int getValue(){
            return value;
        }
        public String toString(){
            return outStaticValue+" Value:"+value;
        }
    }
    
      private  class InnerClass{
        private int value;
        
        public void setValue(int value){
            this.value = value;
        }
        public int getValue(){
            return value;
        }
        public String toString(){
            return outValue+" Value:"+value;
        }
    }
    
   
    public static void main(String[] args) {
      StaticInnerClass sc = new StaticInnerClass();
        
        sc.setValue(20);
        System.out.println(sc);
        
    }
    
}
