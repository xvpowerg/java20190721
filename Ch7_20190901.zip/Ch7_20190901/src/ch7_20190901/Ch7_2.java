/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190901;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author shihhaochiu
 */
public class Ch7_2 {

     static void testForeach(Foreach foreach,List<String> list){
         foreach.foreach(list);
     }
    
    
    public static void main(String[] args) {
        
        List<String>nameList = new ArrayList<>();
        
        nameList.add("Ken");
        nameList.add("Vivin");
        nameList.add("Lindy");
        nameList.add("Iris");
      
        class MyForeach implements Foreach{
            public void foreach(List<String> list){
                
               for (int i =0;i< list.size();i++){
                   System.out.println("name:"+list.get(i));
               } 
                
            }
        }
        
        MyForeach myFor = new MyForeach();
        testForeach(myFor,nameList);
        
    }
    
}
