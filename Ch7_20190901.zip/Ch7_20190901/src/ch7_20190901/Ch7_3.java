/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190901;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author shihhaochiu
 */
public class Ch7_3 {
    
    
    public static void testForeach(Foreach foreach,List<String> list){
        foreach.foreach(list);
    }
    
    public static void main(String[] args) {
      
        // 匿名內部類
        //複寫
        Dog myDog = new Dog(){
            public void bark(){
                System.out.println("喵喵!!");
            }
        };
        myDog.bark();
       //實作介面
          
        List<String>nameList = new ArrayList<>();
        
        nameList.add("Ken");
        nameList.add("Vivin");
        nameList.add("Lindy");
        nameList.add("Iris");
//        testForeach(new Foreach(){
//            public void foreach(List<String>list){
//                for (String name : list){
//                    System.out.print(name+" ");
//                }
//                
//            }
//        
//        },nameList);
//        
       //lambda
//       testForeach(list->{
//           for (String name : list){
//               System.out.print(name+" ");
//           }
//       },nameList);
       
        
    }
    
}
