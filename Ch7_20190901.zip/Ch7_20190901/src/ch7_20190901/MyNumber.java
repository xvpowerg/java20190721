/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190901;

/**
 *
 * @author shihhaochiu
 */
public class MyNumber {
    private String number;
    
    public MyNumber(){
        
    }
    public MyNumber(String number){
        this.number = number;
    }
    public int toInt(){
        return Integer.parseInt(number);
    }
    public float toFloat(){
        return Float.parseFloat(number);
    }
    
    @Override
    public boolean equals(Object obj){
        if (obj==null || obj instanceof MyNumber == false){
            return false;
        }
        MyNumber tmp = (MyNumber)obj;
        return this.number.equals(tmp.number);
        
    }
    
    public String toString(){
        return number;
    }
}
