/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190901;

import java.util.function.Predicate;
import java.util.Arrays;

public class Ch7_8 {

        
        public static int[] filter(Predicate<Integer>predicate,int ... values){
            int[] tmpValue = new int[values.length];
            int index = 0;
            for (int v : values){
                if (predicate.test(v)){
                   tmpValue[index++] = v;
                }
            }
          return Arrays.copyOf(tmpValue, index);
        }
    
    
    public static void main(String[] args) {
        
   int[] array = filter((v)->v > 10,
                        9,6,8,20,70,5,30,11,12,17,18);
            for (int v : array){
                System.out.println(v);
            }
            
            
    }
    
}
