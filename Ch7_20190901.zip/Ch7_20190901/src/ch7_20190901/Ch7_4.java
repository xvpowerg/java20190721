/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190901;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
/**
 *
 * @author shihhaochiu
 */
public class Ch7_4 {

        
     public static void testForeach(ConsumerForeach foreach,List<String> list,Consumer<String> consumer ){
        foreach.foreach(list,consumer);
    }
     
     private static void conFor(List<String> list,Consumer<String> consumer){
         list.forEach(consumer);
     }
     private static void conForConsumer(String name){
         System.out.println("Name:"+name);
     }
       private static void conForConsumer2(String name){
         System.out.print("Name:"+name+" ");
     }
    
    public static void main(String[] args) {
        //以下是要背的   
     //Consumer<T>  void	accept(T t)
     //Function<T,R> R	apply(T t)
     //Predicate<T> boolean	test(T t)
     //Supplier<T> T	get()
     //UnaryOperator<T>  extends Function<T,T>
       List<String>nameList = new ArrayList<>();
        
        nameList.add("Ken");
        nameList.add("Vivin");
        nameList.add("Lindy");
        nameList.add("Iris");
        
//        
//     testForeach(
//        (list,consumer)->{
//            for (String v : list){
//                consumer.accept(v);
//            }
//        },
//        nameList,
//        (name)->{
//             System.out.println("name:"+name);
//        });
             
//     testForeach(
//        (list,consumer)->list.forEach(consumer),
//        nameList,
//        name->System.out.println("name:"+name));

//Method Reference
        testForeach(Ch7_4::conFor,
                nameList,
                Ch7_4::conForConsumer);
        
       testForeach(Ch7_4::conFor,
                nameList,
                Ch7_4::conForConsumer2); 
     
    }
    
}
