/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190901;
import java.util.function.UnaryOperator;


public class Ch7_7 {

    
    static String magerStr(UnaryOperator<String> uop,String ... msg){
        String magStr = "";
        int index = -1;
        for(String v : msg){
            if (++index < msg.length -1){
                 magStr += uop.apply(v);
            }else{
                magStr += v;
            }
          
        }
        return magStr;
    }
    
    
    public static void main(String[] args) {
        String value = magerStr((str)->str+",","A","B","C");
        System.out.println(value);
    }
    
}
