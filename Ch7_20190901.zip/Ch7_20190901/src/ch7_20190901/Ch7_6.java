/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190901;
import java.util.function.Function;
public class Ch7_6 {

    
    public static Student max(Student st1,Student st2,
            Function<Student,Integer> f1){
        
        if (f1.apply(st1) > f1.apply(st2)){
            return st1;
        }
        return st2;
        
    }
    
    public static float stringToFloat(String strNumber,
            Function<String,MyNumber> function){
        return function.apply(strNumber).toFloat();
    }
    
    
    public static void main(String[] args) {
        Student st1 = new Student("Ken",95);
        Student st2 = new Student("Vivin",25);
//     System.out.println(
//             max(st1,st2,st->st.getAge())
//     );
     System.out.println(
             max(st1,st2,Student::getAge)
     );
     
    float price =  stringToFloat("156.25",(str)->new MyNumber(str));
    System.out.println(price > 12);
       price =  stringToFloat("156.25",MyNumber::new);
    System.out.println(price > 12);
    }
    
}
