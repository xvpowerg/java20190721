/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190901;
import java.util.function.Supplier;
import java.util.Random;
import java.util.Arrays;
/**
 *
 * @author shihhaochiu
 */
public class Ch7_5 {

    static int[] genrateLotoo(Supplier<String> supplier){
        int[] lottoNumbers = new int[6];
        String str = supplier.get();
        String[] strNumber = str.split(",");
        
        for (int i=0;i < strNumber.length;i++){
            lottoNumbers[i] = Integer.parseInt(strNumber[i]);
        }
        return lottoNumbers;
    }
    
    static boolean checkLotooNumber(int number,int[] array){
        for (int tmpNumber :  array){
            if (tmpNumber == number){
                 return false;
            }
        }
        return true;
    }
    
    
   static String getLotooNumberStr(){
       Random random = new Random();
       int [] lotton = new int[6];
       int index = -1;
       while(index < lotton.length - 1){
            int lotooNumber = random.nextInt(56)+1;
            //過濾重複
            if (checkLotooNumber(lotooNumber,lotton)){
                  lotton[++index] = lotooNumber;
            }
       }
        Arrays.sort(lotton);
       StringBuffer sb = new StringBuffer();
       String value = "";
       for (int tmp : lotton){
//           value+=tmp;
//           value+=",";
            sb.append(tmp);
            sb.append(",");
       }
       sb.deleteCharAt(sb.length() - 1);
       value = sb.toString();
      // value = value.substring(0,value.length() - 1);
      //1~56 之間的數字
     //格式必須為5,6,7,8,9,1,18的字串
     //字串的數字不可相同
       return value;
   }
    
    public static void main(String[] args) {
    //Supplier<T> T	get()      
        
    //Function<T,R> R	apply(T t)
    //UnaryOperator<T>  extends Function<T,T>
     //Predicate<T> boolean	test(T t)
     //getLotooNumberStr();
    
     
     int[] lotoo = genrateLotoo(Ch7_5::getLotooNumberStr);
     Arrays.stream(lotoo).forEach((n)->System.out.println("Number:"+n));
    }
    
}
