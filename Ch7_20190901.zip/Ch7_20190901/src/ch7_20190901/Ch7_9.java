/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190901;
import java.util.ArrayList;
public class Ch7_9 {

    public static void main(String[] args) {
       ArrayList<Integer> myList = new ArrayList<>();

        myList.add(10);
        myList.add(25);
        myList.add(32);
        myList.add(78);
        
//        for (int i =0;i < myList.size();i++){
//            System.out.println(myList.get(i));
//        }
        
//        for (int v : myList){
//                System.out.println(v);
//        }
        
     //   myList.forEach(System.out::println);
       
     myList.stream().filter((n)->n > 20).
                      forEach(System.out::println);
        
    }
    
}
