/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190901;

import java.util.ArrayList;

/**
 *
 * @author shihhaochiu
 */
public class Ch7_10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Integer> myList = new ArrayList<>();
        
        myList.add(54);
        myList.add(10);
        myList.add(25);
        myList.add(32);
        myList.add(78);
        
        myList.add(1, 86);
        myList.forEach(System.out::println);
        System.out.println("===================");
         ArrayList<Integer> myList2 = new ArrayList<>();
         myList2.add(71);
         myList2.add(94);
         myList2.add(54);
         
        myList.addAll(myList2);
        myList.forEach(System.out::println);
     System.out.println("===================");    
        
     
     //myList.clear();
        //  System.out.println(myList.size());
      //  System.out.println("===================");        
      System.out.println( myList.contains(94));
      System.out.println( myList.contains(658));
      System.out.println( myList.indexOf(94));
       System.out.println( myList.indexOf(658));
       
       System.out.println( myList.indexOf(54));
         System.out.println( myList.lastIndexOf(54));
         myList.remove(Integer.valueOf(94));
        
         System.out.println("===================");   
         myList.forEach(System.out::println);
          
         System.out.println("==================="); 
         myList.removeIf((v)->v < 30);
          myList.forEach(System.out::println);
             
          System.out.println("==================="); 
         myList.replaceAll((v)->v+10);
           myList.forEach(System.out::println);
           myList.set(1, 27);
          
           System.out.println("==================="); 
                myList.forEach(System.out::println);
                
           myList.sort((v1,v2)->v1 - v2);
            System.out.println("==================="); 
               myList.forEach(System.out::println);
               
               
        System.out.println("");
    }
    
}
