/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190901;

import java.util.List;
import java.util.function.Consumer;
/**
 *
 * @author shihhaochiu
 */
public interface ConsumerForeach {
    
    void foreach(List<String> list,Consumer<String> consumer);
    
}
