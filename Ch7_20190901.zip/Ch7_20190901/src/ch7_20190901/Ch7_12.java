/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190901;
import java.util.LinkedList;
public class Ch7_12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //ArrayList 特性
        //1 插入開頭或中間慢
        //2 刪除開頭或中間慢
        //LinkedList
        //1 插入開頭或中間快
        //2 刪除開頭或中間快
        LinkedList<String> list= new LinkedList<>();
        list.add("Ken");
        list.add("Vivin");
        list.add("Lindy");
         list.add("Sead");
       list.forEach(System.out::println);
       
       
        System.out.println("================"); 
     System.out.println(list.peek());
     System.out.println("================"); 
    list.forEach(System.out::println);
     
//    System.out.println("================"); 
//    System.out.println(list.poll());
//    System.out.println("================"); 
System.out.println("================");     
    String value = null;
//    
//    
    while( (value =list.poll()) != null  ){
        System.out.println(value);
    }
    System.out.println("================");  
    System.out.println("size:"+list.size()); 


//
//    for ( String tmp =list.poll();tmp!= null;tmp =list.poll()){
//           System.out.println(tmp);
//       }    
    }
    
}
