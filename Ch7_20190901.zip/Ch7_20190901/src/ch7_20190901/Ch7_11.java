/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190901;
import java.util.ArrayList;
/**
 *
 * @author shihhaochiu
 */
public class Ch7_11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        MyNumber n1 = new MyNumber("25");
        MyNumber n2 = new MyNumber("83");
        MyNumber n3 = new MyNumber("72");
        MyNumber n4 = new MyNumber("98");
        
         MyNumber n5 = new MyNumber("25");
         System.out.println(n5.equals(n1));
        ArrayList<MyNumber> list = new ArrayList<>();
        list.add(n1);
        list.add(n2);
        list.add(n3);
        list.add(n4);
        list.forEach(System.out::println);
        System.out.println("==============");
        list.remove(n5);
        list.forEach(System.out::println);
    }
    
}
