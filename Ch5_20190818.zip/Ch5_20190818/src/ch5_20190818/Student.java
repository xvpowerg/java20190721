/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190818;
import java.util.Random;
public class Student  extends Person{
    private int[] scores = new int[3];
    private  static int[] Numbers = new int[100];
    private int index = -1;
    
    {
       for (int i =0;i <scores.length;i++){
            scores[i] = -1;
        }    
       
   
    }
    
    static{
         Random ra = new Random();
       for (int i =0;i< Numbers.length;i++){
          Numbers[i]  = ra.nextInt(50000);           
       }         
    }
    
    public static void printNumbers(){
        for (int i =0;i<10;i++){
            System.out.println(Numbers[i]);
        }
    }
    
    public Student(String name,int age,float height){
        super(name,age,height);
       
    }
    public Student(String name,int age){
         super(name,age,0);        
        //this(name,age,0);
    }
    
    public void addScore(int score){
        ++index;
        if (index >=  this.scores.length){
            throw new IndexOutOfBoundsException("超過3筆成績");
        }      
        scores[index]= score;
        //1 如果超過3比拋出例外
          // IndexOutOfBoundsException 超過3筆成績
       //2 toString 希望可看到socre列出
       //Kne:18:168:92,57,86       
    }
    
    public String toString(){
        String value = "";
        for (int index = 0;index < scores.length;index++){       
           value += scores[index];
           if (index +1 != scores.length){
              value+=","  ;
            }
        }
        return super.toString()+":"+value;
    }
}
