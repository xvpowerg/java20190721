/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190818;

/**
 *
 * @author howard
 */
public class Ch5_5 {

  
    public static void main(String[] args) {
     
        Student st1 = new Student("Vivin",11,165);
        System.out.println(st1);
       st1.printNumbers(); 
        Student st2 = new Student("Ken",11);
         System.out.println(st2);
         st2.printNumbers();
         
         
    }
    
}
