/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190818;

/**
 *
 * @author howard
 */
public class Ch5_8 {
    //遮蔽看類別
    //複寫看物件
    //遮蔽 所有靜態與屬性都是遮蔽    
    public static void main(String[] args) {
//        TestShading1 ts1 = new TestShading2();
//        ts1.value1 = "testValue";
//        ts1.value2 = "testValue2";
//        
//        System.out.println(ts1.value1);
//        System.out.println(ts1.value2);
//        ts1.staticShowInfo();
//        ts1.print();        

//    TestShading2 ts2 = new TestShading2();
//         ts2.value1 = "testValue";
//         ts2.value2 = "testValue2";        
//        System.out.println(ts2.value1);
//        System.out.println(ts2.value2);
//        ts2.staticShowValue2();

//        TestShading1 ts3 = new TestShading2();
//            ts3.value3 = "testValue3";
//            ts3.print3();


        TestShading1 ts4 = new TestShading2();
        ts4.setTest3("set Test3 value3");
        System.out.println(ts4.value3);
            
    }
    
}
