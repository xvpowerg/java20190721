/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190818;
import java.io.IOException;
/**
 *
 * @author howard
 */
public class Test1 {
    public void testPublic(){
        System.out.println("Test1 Public");
    }
    protected void testProtected(){
        System.out.println("Test1 Protected");
    }
    void testDefault(){
        System.out.println("Test1 Default");
    }
    private void testPrivate(){
        System.out.println("Test1 Default");
    }
    
    public int testInt(){
        return 0;
    }
    
    public Test1 testTest1(){
        return null;
    }
    
    
    public void testMethod(Test1 t1){
        System.out.println(t1);
    }
    
    public void testException() throws IOException{
        
    }
    
}
