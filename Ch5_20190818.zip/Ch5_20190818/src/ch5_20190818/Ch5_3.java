/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190818;

/**
 *
 * @author howard
 */
public class Ch5_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Student st2 = new Student("Ken",25,171);  
        st2.addScore(75);
        st2.addScore(92);
        st2.addScore(83);
      
        System.out.println(st2);
        
    }
    
}
