/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190818;

//只要有抽象方法 就必須是抽象類別
//抽象類別無法new
//不可為final
//抽象的方法也不可為final
public abstract class Animal {
    private String name;
    public abstract void runing();
    
    public Animal(String name){
        this.name = name;
    }
    public String getName(){
        return name;
    }
    
    public String toString(){
        return name;
    }
}
