package ch5_20190818;
public class Ch5_1 {
    /*
    複寫規則(Override)
    1 讀取權限只能開放
    2 私有不能算是複寫
    3 回傳類型如果是基本型態必須一模一樣
    4 回傳類型如果是非基本型態 可以一樣或子類型
    5 方法名稱跟傳入參數要一樣
    6 例外拋出 可選拋出一樣的或子類或不拋出  (一樣的或子類 針對的是必要例外檢測型的)
    */
    public static void main(String[] args) {
       
        /*
        public 
        protected
        default
        private
        */
        Test1 t1 = new Test2();
        t1.testPublic();
        t1.testProtected();
        t1.testDefault();
        
    }
    
}
