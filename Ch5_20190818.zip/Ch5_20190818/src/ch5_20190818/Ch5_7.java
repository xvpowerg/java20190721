/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190818;
//static 的先產生
//nonstatic 的後產生　
public class Ch5_7 {
    {
     System.out.println("nonStatic init 1");        
    }
    static {
          System.out.println("Static init 1");        
      }    
    public Ch5_7(){
        System.out.println(" Ch5_7() ");
    }    
    public static void main(String[] args) {
       Ch5_7 ch571 = new Ch5_7();
       Ch5_7 ch572 = new Ch5_7();     
    }
    static {
        System.out.println("Static init 2");        
    }  
    {
        System.out.println("nonStatic init 2");        
    }    
}
