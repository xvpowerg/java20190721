/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190818.p2;
import ch5_20190818.Test1;
public class Test3 extends Test1 {
    @Override
    public void testPublic(){
        System.out.println("Test3 Public");
    }
    
    @Override
    protected void testProtected(){
       System.out.println("Test3 Protected");  
    }
//    @Override 這裡不是正確的複寫 因為Default 無法跨package讀取
    void testDefalut(){
        System.out.println("Test3 testDefalut");        
    }
    //@Override
   private void testPrivate(){
        System.out.println("Test3 private");
   }
}   
