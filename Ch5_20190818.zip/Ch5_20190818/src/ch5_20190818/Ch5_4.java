/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190818;

/**
 *
 * @author howard
 */
public class Ch5_4 {
 
    public static void main(String[] args) {
        TestStaitc ts1 = new TestStaitc();
        TestStaitc ts2 = new TestStaitc();    
        
        ts1.objValue = 123;
        ts2.objValue = 789;
        
        ts1.staticValue = 345;
        ts2.staticValue = 678;
        
        System.out.println("ts1.objValue:"+ts1.objValue);
        System.out.println("ts2.objValue:"+ts2.objValue);
        
        System.out.println("ts1.staticValue:"+ts1.staticValue);
        System.out.println("ts2.staticValue:"+ts2.staticValue);
    }
    
}
