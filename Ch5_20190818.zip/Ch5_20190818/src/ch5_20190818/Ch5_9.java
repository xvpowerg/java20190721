/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190818;

/**
 *
 * @author howard
 */
public class Ch5_9 {

    public static void main(String[] args) {
       Animal cat1 = new Cat("Kitty");
       cat1.runing();
       System.out.println(cat1);
        Animal dog1 = new Dog("Snopy");
        System.out.println(dog1);
    }
    
}
