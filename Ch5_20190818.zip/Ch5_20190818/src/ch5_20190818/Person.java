/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190818;

/**
 *
 * @author howard
 */
public class Person {
    private String name;
    private int age;    
    private float height;
    
    public Person(String name,int age,float height){
        this.name = name;
        this.age = age;
        this.height = height;
    }
    
    public String getName(){
        return name;
    }
   public int getAge(){
        return age;
    }
      public float getHeight(){
        return height;
    }
      
    public String toString(){
        return this.getName()+":"+this.getAge()+":"+this.getHeight();
    }
    
    public boolean equals(Object obj){
        if (obj == null || obj instanceof Person == false){
            return false;
        }
        Person person = (Person)obj;
        return this.getName().equals(person.getName()) && this.getAge() == person.getAge();
    }
    
}
