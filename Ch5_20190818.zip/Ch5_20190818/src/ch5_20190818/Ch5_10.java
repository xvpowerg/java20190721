/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190818;

/**
 *
 * @author howard
 */
public class Ch5_10 {

    public static void main(String[] args) {
        String str = "12A34B567";
        System.out.println(str.length());
        int digitCount = 0;
        for (int i =0;i < str.length();i++){
            char tmp = str.charAt(i);
            if (Character.isDigit(tmp)){
                 digitCount++;    
            }            
        }
        System.out.println(digitCount);
        
        String sub1 = str.substring(2);
        System.out.println(sub1);
      String sub2 = str.substring(2,7);
        System.out.println(sub2); 
        
        
    }
    
}
