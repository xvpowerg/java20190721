/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190818;

import java.io.IOException;
import java.io.FileNotFoundException;
import java.sql.SQLException;

public class Test2  extends Test1{
      public void testPublic(){
        System.out.println("Test2 Public");
    }
      //public protected
      @Override 
     protected void testProtected(){
        System.out.println("Test2 testProtected");
      }
       //public protected default
     @Override 
     void testDefault(){
         System.out.println("Test2 testDefault"); 
     }
     
    // @Override  檢查是否是正確的複寫
     // @Override 
     private void testPrivate(){
        System.out.println("Test2 testPrivate");    
     }
     
//因為父類別回傳為int所以 回傳類型只能是int         
//    public short testInt(){
//        return 0;
//    }
     
    public Test2 testTest1(){
        return null;
    }
    
  //  @Override
   public void testMethod(Test2 t1){
        System.out.println(t1);
    }
   
     public void testException() throws FileNotFoundException{
        
    }
   
}
