/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190818;

/**
 *
 * @author howard
 */
public class Ch5_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            Student st = new Student("Ken",25,171);      
            Student st2 = new Student("Ken",25,171);       
            
            System.out.println(st);
            System.out.println(st.equals(st2));
            
        System.out.println(st.getClass().getName()+"@"+
                Integer.toHexString(st.hashCode()));
    }
    
}
