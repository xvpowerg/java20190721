/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190818;
public class TestShading1 {
    public String value1;
    public static String value2;
    public String value3;
     
    public static void staticShowInfo(){
        System.out.println("ShowInfo TestShading1");
    }
    
    public void print(){
          System.out.println("print TestShading1");
    }    
    
   public static void staticShowValue2(){
        System.out.println("Value2:"+value2);
    }
   
     public void print3(){
          System.out.println("print value3:"+value3);
    }    
     
     public void setTest3(String value3 ){
          this.value3 = value3;
      }
    
}
