/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20190721;

/**
 *
 * @author howard
 */
public class Ch1_12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         //1~6 熱帶低氣壓
        //7~8 輕度颱風
        //9~10 中度颱風
        //11~15 強度颱風
        //16 超強度颱風
        int power = 8;
        switch(power){
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:  
               System.out.println("熱帶低氣壓");
           break;
            case 7:
            case 8:
             System.out.println("輕度颱風");   
              break;
           case 9:
            case 10:
             System.out.println("中度颱風");   
              break;
           case 11:
            case 12:
            case 13:    
            case 14:        
            case 15:            
                System.out.println("強度颱風");
              break;  
            default:
                System.out.println("超強度颱風");
                break;
        }
        
    }
    
}
