/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20190721;

/**
 *
 * @author howard
 */
public class Ch1_1 {

    public static void main(String[] args) {
        //整數
        //bit -> 0 or 1 
        
         //byte 8bit -128~127 要記 
         //short 16bit -32768~32767
         //int  32bit -2147483648~2147483647  default
         //long 64bit 
         
         int value = 129;
         System.out.println(value);
         long value2 = 2147483648L;
         System.out.println(value2);
        //浮點數 
          //float 32bit  *
          //double 64bit default
        float pi = 3.1415f;
        double e = 2.71828;
        //文字 大小關係 數字 < 大寫 < 小寫 < 中文
        char c1 = 'A';
        int cName = c1;
        System.out.println(cName);
         char c2 = 'a';
         cName = c2;
         System.out.println(cName);
         char c3 = '0';
         cName = c3;
         System.out.println(cName);
        //布林
        boolean isOpen = true;
        boolean isClose = false;
        System.out.println(isOpen);
        System.out.println(isClose);
        
    }
    
}
