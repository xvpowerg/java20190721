/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20190721;

/**
 *
 * @author howard
 */
public class Ch1_16 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
   
//        for (int i =1;i<=5;i++){
//            if (i == 3){
//                //break;
//                continue;
//            }
//            System.out.println(i);
//        }
        
//         for (int i =1;i<=5;i++){
//             System.out.println("Start:"+i);
//             for (int k =1; k<=3; k++){
//               // System.out.println(i);
//                if (i == 3){
//                   //break;
//                   continue;
//              }
//                 //System.out.println(i);   
//             }
//             System.out.println("End:"+i);
//   
//        }

        tag1:          
         for (int i =1;i<=5;i++){
             System.out.println("Start:"+i);
             tag2:  
             for (int k =1; k<=3; k++){
               // System.out.println(i);
                if (i == 3){
                   //break tag1;
                  continue tag1;
              }
                 System.out.println(i);   
             }
             System.out.println("End:"+i);   
        }


    }
    
}
