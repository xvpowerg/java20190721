/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20190721;

public class Ch1_4 {
    public static void main(String[] args) {
     
        boolean b1 = true;
        boolean b2 = false;
        
        //且　兩邊為真才為真 會有短路現象 當左邊為false會發生短路
         System.out.println(b1 && b2);
         int i= 2;
         boolean b3 = ++i>1 && ++i < 5;
         System.out.println(b3);
         System.out.println(i);
         System.out.println("================="); 
          int y= 2;
         boolean b4 = ++y<1 && ++y < 5;  
         System.out.println(b4);
         System.out.println(y);
        //或　單邊為真就是真 會有短路現象 只要左邊為true就會短路
         System.out.println(b1 || b2);
         
         int x = 1;
         boolean b5 = ++x < 3 ||  ++x > 2;
         System.out.println(b5);
          System.out.println(x);
          
           b5 = ++x < 3 ||  ++x > 2;
          System.out.println(b5);
          System.out.println(x);
        //反向 唱反調
        //System.out.println(!b1);
        //互斥 一真一假才為真
        //System.out.println(b1 ^ b2);   
        
        
    }
    
}
