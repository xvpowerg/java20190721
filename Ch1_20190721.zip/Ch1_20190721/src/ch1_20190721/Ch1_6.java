/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20190721;

/**
 *
 * @author howard
 */
public class Ch1_6 {

    public static void main(String[] args) {
     
        
        //變數命名規則　開頭只能是$ _ 或英文字母　　第二開始可以使用　$ _ 或英文字母或數字
        //不可宣告　keyword
        int _$bc = 10;
        
        int binary = 0b0100100;//常用
        int oct = 0023;
        //A =10 B= 11 C = 12 D = 13 E = 14 F = 15
        int hex = 0xFF0011;//常用
         System.out.println(binary);
           System.out.println(oct);
         System.out.println(hex);
        //數字宣告可加_ 
        //口訣 底線前後必須是底線或數字
         int v1 = 12_3_________________5;
         System.out.println(v1);
          //int v2 = 0b_01_010_1;// 錯誤
          int v3 = 0xAA00F_F;// F 表示15所以OK
          int v4 = 0_7_1_23;//
          float f1 = 127.56_3f;//小數點前後不可加上_
          
         
    }
    
}
