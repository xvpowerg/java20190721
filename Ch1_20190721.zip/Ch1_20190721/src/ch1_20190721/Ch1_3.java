/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20190721;

/**
 *
 * @author howard
 */
public class Ch1_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int count = 0;
       float number = 20;
       count += number;
       //count = count +number;
       System.out.println(count);
      
       int i =1;
      //分解動作 
      //System.out.println(i);
      //i = i +1
       System.out.println(i++);  
       
      //分解動作 
      //i = i +1
      //System.out.println(i);      
       System.out.println(++i);
        
       int k = 2;       
       int g = 5 + k++ - 2  * ++k - 3 + k++;       
       
       System.out.println("k:"+k);
       System.out.println("g:"+g);
       
       
    }
    
}
