/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20190721;

/**
 *
 * @author howard
 */
public class Ch1_11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int v1 = 10;
        
        //在case不可有重複的內容
        //以下會編譯錯誤
//        switch(v1){
//            case 10111:
//                break;
//            case 101__11:
//                break;
//        }
//switch case 碰到break才會離開　不然會一路執行下去
int v2 = 1;
        switch(v2){
            default:
                System.out.println("default!!");
            case 1:
                 System.out.println("Jump");
               break;
            case 2:
                System.out.println("Walk");
                break;
        }
    }
    
}
