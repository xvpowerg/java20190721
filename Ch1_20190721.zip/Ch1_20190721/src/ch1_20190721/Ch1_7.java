/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20190721;

import java.util.Scanner;
public class Ch1_7 {
    public static void main(String[] args) {
        float height = 180.56f;
        int age = 25;
        String name = "Ken";
        //%s 字串　%d 整數 %f　浮點數　　%n 斷行
//        System.out.printf("姓名%s年齡%d 身高%.2f %n",
//                name,age,height);
        Scanner scann = new Scanner(System.in);
        System.out.println("請輸入年齡：");
        int value = scann.nextInt();
        
        if (value >= 18){
            System.out.println("成年");
        }else{
            System.out.println("未成年");
        }
        
        
        
    }
    
}

