/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20190721;

/**
 *
 * @author howard
 */
public class Ch1_2 {

    public static void main(String[] args) {
      int a1 = 2;
      int a2 = 10;
      System.out.println(a1 / a2);//取商數
      System.out.println(a1 / (float)a2);
      
      //a1 % a2 的結假設為 m 那麼 a2 > m >=0  a1可無限大
      System.out.println(a1 % a2);
      long a3 = 1231231534534L;
      System.out.println(a3 % a2);
     
      //複合指定運算子
      int hp = 100;
      hp -= 30; 
      System.out.println(hp);
      hp *= 10;
      System.out.println(hp);
      
      int i =1;
      i++;
      ++i;
      System.out.println(i);
      i--;
      System.out.println(i);
      
      
    }
    
}
