/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20190721;

/**
 *
 * @author howard
 */
public class Ch1_9 {

    public static void main(String[] args) {
       //參數可以是byte shoort int char String enum
       final int PLAY =1;
       final int STOP =2;
       final int EXIT =3;       
        int action = EXIT;
       //case 的變數只可用常數,常數不可再修改的數
       
        switch(action){             
            case PLAY:
              System.out.println("Play");
                break;
            case STOP:
                System.out.println("Stop");
                break;
            case EXIT:
                System.out.println("Exit");
                break;
           default:
                 System.out.println("Error!");
                break;
        }
        
        
    }
    
}
