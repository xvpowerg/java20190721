/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20190721;

/**
 *
 * @author howard
 */
public class Ch1_8 {


    public static void main(String[] args) {
      
        //1~6 熱帶低氣壓
        //7~8 輕度颱風
        //9~10 中度颱風
        //11~15 強度颱風
        //16 超強度颱風
        int power = 15;
        
        if (power >= 16){
            System.out.println("超強度颱風");
        }else if (power >= 11){
            System.out.println("強度颱風");
        }else if(power >= 9){
            System.out.println("中度颱風");
        }else if(power >= 7){
             System.out.println("輕度颱風");
        }else if(power >= 1){
            System.out.println("熱帶低氣壓");
        }else{
            System.out.println("無");
        }
        
        
    }
    
}
