/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20190721;

public class Ch_14 {

    public static void main(String[] args) {
        int count = 10;
        while(count >= 1){
            System.out.println(count--);            
        }
           System.out.println("============");
        int count2= 1;
        do{
            System.out.println(count2);
        }while(count2 > 10);
        
        int count3= 10;
        do{
            if (count3 % 2 == 0){
              System.out.println(count3);  
            }
            count3--;
             //System.out.println(count3--);              
        }while(count3 >= 1);
        
    }
    
}
