/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20190721;

/**
 *
 * @author howard
 */
public class Ch_13 {
   static int step1(){
       System.out.println("step1!");
       return 1;
   }   
   static boolean step2(){
       System.out.println("step2!");
       return true;
   }
    static void  step3(){
       System.out.println("step3!");       
   }
     static void  step4(){
       System.out.println("step4");       
   }
   
    public static void main(String[] args) {
         for (int i =step1();i<=5&&step2();i++,step4()){
                 System.out.print(i);
                step3();
            }
        
        
//        for (int i =1  ;  i <= 5 ; i++ ){
//            System.out.print(i+" ");
//        }
//        System.out.println();
//        
//         for (int i =1,k=7  ;  i <= 5 && k >= 1; i++ , k--){
//            System.out.println(i+" "+k+" ");
//        }
         

        
    }
    
}
