/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20190721;

/**
 *
 * @author howard
 */
public class Ch1_5 {

    public static void main(String[] args) {
        int v1 = 42;//‭00101010‬
        int v2 = 53;//‭00110101‬
        
        //100000
        System.out.println(v1 & v2);
        //00111111
        System.out.println(v1 | v2);
        //00011111
        int pKey = v1 ^ v2;
        System.out.println(pKey);
        System.out.println(v1 ^ pKey);
        System.out.println(v2 ^ pKey);
        
        int n1 = 2;
        int k = 4;
        System.out.println(n1 << k); // n1 * 2 ^ k
       
        int n2 = 32;
        int d = 1;
        System.out.println(n2 >> d); // n2 / 2 ^ d
        System.out.println(n2 >>= d);
        System.out.println(n2 >>= d);
        
        
    }
    
}
