/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20190721;

/**
 *
 * @author howard
 */
public class Ch1_15 {

    public static void main(String[] args) {
      
//        for (int i =2;i<=9;i++){            
//            for (int k = 1  ; k<= 9 ; k++ ){                
//                System.out.printf("%d*%d=%2d ",i,k,i*k);
//            }
//                System.out.println();            
//        }
        int i =2,k =1;
        while(i <= 9){
             k = 1;
            while(k <=9){
                System.out.printf("%d*%d=%2d ",i,k,i*k);
                k++;
            }      
            System.out.println();
            i++;
        }
        
    }
    
}
