/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20190721;

/**
 *
 * @author howard
 */
public class Ch1_10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //String name = "Ken"; //正常
       /*String name = null  //java.lang.NullPointerException
       
       switch(name){
           case "Ken":
               System.out.println("助理工程師");
               break;
           case "Vivin":
               System.out.println("業務");
               break;    
           case "Lindy":
               System.out.println("高級工程師");
               break;
           default:
               System.out.println("無");
               break;
       }*/
       
       int a1 = 10;
       int b2 = 10;
       System.out.println(a1 == b2);
       
      String s1 = "Ken";
      String s2 = "Ken";
        System.out.println(s1 == s2);
        
       String s3 = "Ken";
      String s4 = new String("Ken");
      System.out.println(s3.equals(s4));   
 //null 一無所有     
// java.lang.NullPointerException   執行錯誤
//       String s5 = null;
//      System.out.println(s5.equals(s4));   
    }
    
}
