/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190922;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 *
 * @author xvpow
 */
public class Ch10_9 {

    public static void main(String[] args) {
         Stream<String> stream=  Stream.of("Ken","Vivin","Lindy","Tom","Iris","Join");
        
//       Map<Integer,List<String>> groupMap =
//               stream.collect(Collectors.groupingBy(n->n.length()));
//       
//       System.out.println(groupMap);
    Map<Integer,String> map =   stream.collect(Collectors.groupingBy(n->n.length(),
                                Collectors.joining(",")));
        System.out.println(map);
        
        
        
    }
    
}
