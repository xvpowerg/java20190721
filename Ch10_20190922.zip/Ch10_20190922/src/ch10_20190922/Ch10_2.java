/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190922;

/**
 *
 * @author xvpow
 */
public class Ch10_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Employee emp1 = new Employee(10,"Ken");
       emp1.appedSkill(new Skill(1,"Java"));
       emp1.appedSkill(new Skill(2,"Python"));
       System.out.println(emp1);

        Employee emp2 = new Employee(10,"Vivin");
       emp2.appedSkill(null);
       emp2.appedSkill(null);
       System.out.println(emp2);       
       
//       if (emp2.getName()!= null && emp2.getName().equals("Vivin")){
//           System.out.println("黑名單");           
//       }       

      emp2.getName().ifPresent((n)->{
                if (n.equals("Vivin")){
                    System.out.println("黑名單");
                }      
      });
      
       //Employee 提供機制倫巡Skill
       
    }
    
}
