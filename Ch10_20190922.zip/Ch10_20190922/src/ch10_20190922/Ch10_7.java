/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190922;
import java.util.ArrayList;
import java.util.IntSummaryStatistics;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Ch10_7 {

    public static void main(String[] args) {
      
//       Stream<String> stream=  Stream.of("Ken","Vivin","Lindy","Tom");
//       stream.map((n)->n.length()).forEach(System.out::println);
        
         ArrayList<Employee> empList = new ArrayList();
        Employee emp1 = new Employee(10,"Ken");
       emp1.appedSkill(new Skill(1,"Java"));
       emp1.appedSkill(new Skill(2,"Python"));
      
       Employee emp2 = new Employee(11,"Vivin");
       emp2.appedSkill(new Skill(1,"PHP"));       
       
        Employee emp3 = new Employee(10,"Ken");
       emp3.appedSkill(new Skill(1,"Java"));
       emp3.appedSkill(new Skill(2,"Python"));
       
      Employee emp4 = new Employee(6,"Join");
       emp4.appedSkill(new Skill(1,"SQL"));     
       emp4.appedSkill(new Skill(2,"C++"));     
       emp4.appedSkill(new Skill(3,"Java"));     
       
      Employee emp5 = new Employee(7,"Iris");
       emp5.appedSkill(new Skill(1,"Manager"));     
       emp5.appedSkill(new Skill(2,"PMP"));     
         
       Employee emp6 = new Employee(2,"Tom");
       emp6.appedSkill(new Skill(1,"C#"));     
       emp6.appedSkill(new Skill(2,"Ruby"));     
       
      Employee emp7 = new Employee(5,"Tom");
       emp7.appedSkill(new Skill(1,"Unity"));     
       emp7.appedSkill(new Skill(2,"Ruby"));  
       
    empList.add(emp1);
    empList.add(emp2);
    empList.add(emp3);
    empList.add(emp4);
    empList.add(emp5);
    empList.add(emp6);
    empList.add(emp7);    
       
      // empList.stream().forEach(System.out::println);
//       empList.stream().map(emp->emp.skillSize()).
//               distinct().sorted().forEach(System.out::println);
//       
//        IntSummaryStatistics intSum = 
//                empList.stream().mapToInt(emp->emp.skillSize()).summaryStatistics();
//        System.out.printf("平均技能數量為:%.0f%n",intSum.getAverage());
        
        //empList.get(0).getSkillStream().
//                forEach(skill->System.out.println(skill));
        
//     empList.stream().map(emp->emp.getSkillStream()).
//             map(str->str.findFirst().get()).
//             forEach(System.out::println);
        
    empList.stream().flatMap(emp->emp.getSkillStream()).
        forEach(System.out::println);
    System.out.println("=========================");
    
    empList.stream().flatMapToInt(emp->IntStream.of(emp.skillSize())).
            forEach(System.out::println);
    }
    
}
