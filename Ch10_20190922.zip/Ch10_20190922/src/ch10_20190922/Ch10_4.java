/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190922;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Optional;
/**
 *
 * @author xvpow
 */
public class Ch10_4 {


    public static void main(String[] args) {
         ArrayList<String> list = new ArrayList();
        list.add("Ken");
        list.add("Vivin");
        list.add("Lindy");
        list.add("Vivin");
        list.add("Tom");
        
        list.stream().parallel().forEach(System.out::println);
        System.out.println("====================");
        list.stream().parallel().forEachOrdered(System.out::println);
        
         ArrayList<Integer> numberList = new ArrayList();
         numberList.add(10);
         numberList.add(50);
         numberList.add(60);
         numberList.add(30);
        Optional<Integer> optionMax =  numberList.stream().
                max(Comparator.comparing(v->v));
        optionMax.ifPresent((max)->System.out.println("Max:"+max));
         
        Optional<Integer> optionalMin = numberList.stream().min(Comparator.comparing(v->v));
        Integer mini = optionalMin.orElse(0);
        System.out.println("Min:"+mini);
        numberList.stream().forEach(v->System.out.print(v+" "));
            System.out.println();
      numberList.stream().skip(2).forEach(v->System.out.print(v+" "));
           System.out.println();
        numberList.stream().sorted().forEach(System.out::println);
        
        
        
        
        
    }
    
}
