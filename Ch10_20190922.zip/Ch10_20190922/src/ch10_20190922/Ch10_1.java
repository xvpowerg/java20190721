/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190922;

import java.util.stream.Stream;
import java.util.ArrayList;
import java.util.Optional;
public class Ch10_1 {

    public static void main(String[] args) {
      ArrayList<String> list = new ArrayList();
        list.add("Ken");
        list.add("Vivin");
        list.add("Lindy");
        list.add("Vivin");
        list.add("Tom");
        long count = list.stream().count();
        System.out.println(count);
        count = list.stream().distinct().count();
        System.out.println(count);
        
        Optional<String> nameOptional = list.stream().findFirst();
        System.out.println(nameOptional.get());
        nameOptional = list.stream().findAny();
         System.out.println(nameOptional.get());
    }
    
}

