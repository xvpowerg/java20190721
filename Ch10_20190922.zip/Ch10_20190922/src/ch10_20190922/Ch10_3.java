/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190922;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Random;

public class Ch10_3 {
        static String genString(){
            StringBuffer sb = new StringBuffer();
            Random random = new Random();
            for (int i =1;i<=5;i++){
                int n1 = random.nextInt(26)+'A';
                sb.append((char)n1);
            }
            return sb.toString();
        }
  
    public static void main(String[] args) {
       Optional option =   Optional.empty();
       System.out.println(option.isPresent());
       String value = "V1";
      // String value = null;
      Optional op1 =  Optional.of(value);//參數不可為null 如果填入null會拋出例外
      System.out.println(op1);
      Optional op2 =  Optional.ofNullable(value);   
      System.out.println(op2);
      
      //不存在
       Optional<String> op3 =  Optional.ofNullable(null);   
       if (op3.isPresent()){
            System.out.println(op3.get());    
       }
       String msg = op3.orElse("Empty");
       System.out.println(msg);        
       //使用Method Referace
       // 當我的Optional 不存在 時 回傳一組
       //使用亂數方式拼湊的 大寫英文字母字串
       //長度為5
//       String value2 = op3.orElseGet(Ch10_3::genString);
//       System.out.println(value2);
      // op3.orElseThrow(NoSuchElementException::new);
      op3.orElseThrow(()->new NoSuchElementException("無資料"));
      
    }
    
}
