/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190922;

import java.util.ArrayList;
import java.util.Comparator;
/**
 *
 * @author xvpow
 */
public class Ch10_5 {
    

    public static void main(String[] args) {
        ArrayList<Employee> empList = new ArrayList();
        Employee emp1 = new Employee(10,"Ken");
       emp1.appedSkill(new Skill(1,"Java"));
       emp1.appedSkill(new Skill(2,"Python"));
      
       Employee emp2 = new Employee(11,"Vivin");
       emp2.appedSkill(new Skill(1,"PHP"));       
       
        Employee emp3 = new Employee(10,"Ken");
       emp3.appedSkill(new Skill(1,"Java"));
       emp3.appedSkill(new Skill(2,"Python"));
       
      Employee emp4 = new Employee(6,"Join");
       emp4.appedSkill(new Skill(1,"SQL"));     
       emp4.appedSkill(new Skill(2,"C++"));     
       emp4.appedSkill(new Skill(3,"Java"));     
       
      Employee emp5 = new Employee(7,"Iris");
       emp5.appedSkill(new Skill(1,"Manager"));     
       emp5.appedSkill(new Skill(2,"PMP"));     
         
       Employee emp6 = new Employee(2,"Tom");
       emp6.appedSkill(new Skill(1,"C#"));     
       emp6.appedSkill(new Skill(2,"Ruby"));     
       
      Employee emp7 = new Employee(5,"Tom");
       emp7.appedSkill(new Skill(1,"Unity"));     
       emp7.appedSkill(new Skill(2,"Ruby"));  
       
    empList.add(emp1);
    empList.add(emp2);
    empList.add(emp3);
    empList.add(emp4);
    empList.add(emp5);
    empList.add(emp6);
    empList.add(emp7);    
    //1去除Ken重複
    empList.stream().forEach(System.out::println);  
    System.out.println("===================");
    empList.stream().distinct().forEach(System.out::println);   
    //2 幫我排序 
     // 1 先使用技能的數量 越多的排上
     //2 使用name排序
     //3 使用ID
        System.out.println("=========Sort==========");
        Comparator<Employee> cmp=
                Comparator.<Employee,Integer>comparing(e->e.skillSize()).
                        reversed().thenComparing(emp->emp.getName().get()).
                        thenComparing(emp->emp.getId());
        
        empList.stream().distinct().sorted(cmp).
                forEach(System.out::println);
        
    }
    
}
