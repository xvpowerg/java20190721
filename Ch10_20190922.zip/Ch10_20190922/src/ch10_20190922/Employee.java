/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190922;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

/**
 *
 * @author xvpow
 */
public class Employee {
    private int id;
    private String name;
    private  List<Skill> skillList = new ArrayList<>();
    private Optional<String> optioName;
    public Employee(int id,String name){
        this.id = id;
        optioName = Optional.ofNullable(name);
        this.name = name;
    }
    
    public Optional<String> getName(){
        return optioName;
    }
    
    public int getId(){
        return id;
    }
    public void appedSkill(Skill skill){
        skillList.add(skill);
    }
    
    public int skillSize(){
        return skillList.size();
    }
    
    public Stream<Skill> getSkillStream(){
        return this.skillList.stream();
    }
    
    
    public boolean equals(Object obj){
        if (obj == null || obj instanceof Employee == false ){
            return false;
        }
        Employee emp = (Employee)obj;
        return this.id == emp.id && this.name.equals(emp.name);
    }
    
    public int hashCode(){
        return this.id + name.hashCode();
    }
    public String toString(){
        return id+":"+name+":"+skillList;
    }
}
