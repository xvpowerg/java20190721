/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190922;
import java.util.stream.IntStream;
import java.util.IntSummaryStatistics;
public class Ch10_6 {

    public static void main(String[] args) {
        IntStream intStream =  IntStream.of(10,5,9,8,1,7);        
        IntSummaryStatistics intSum = intStream.summaryStatistics();
        System.out.printf("%.2f%n",intSum.getAverage());
        System.out.println(intSum.getCount());
        System.out.println(intSum.getMax());
        System.out.println(intSum.getMin());
        
    }
    
}
