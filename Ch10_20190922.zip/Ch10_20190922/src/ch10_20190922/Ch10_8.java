/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190922;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 *
 * @author xvpow
 */
public class Ch10_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       Stream<String> stream=  Stream.of("Ken","Vivin","Lindy","Tom","Iris","Join");
//      List<String>  list =
//              stream.filter((n)->n.length() > 3).collect(Collectors.toList());
//        list.forEach(System.out::println);
        
//       LinkedList<String> list2 = stream.filter((n)->n.length() >3).sorted().
//                collect(Collectors.toCollection(LinkedList::new));
//       System.out.println(list2);
    TreeSet<String> set = stream.collect(Collectors.toCollection(TreeSet::new));
    System.out.println(set);
     Stream<String> stream2=Stream.of("Ken","Iris","Howard");     
   Map<String,Integer>  map =  
           stream2.collect(Collectors.toMap((n)->n, (n)->n.length()));
   System.out.println(map);
    
   
       Stream<String> stream3=Stream.of("Ken","Iris","Howard","Ken");     
     Map<String,Integer> map2 = 
             stream3.collect(Collectors.toMap(k->k, v->v.length(),
                     (nv,ov)->{return nv+ov;},TreeMap::new));
     System.out.println(map2);
     
     Stream<String> stream4 = Stream.of("Ken","Iris","Howard",
                                      "Ken","Iris","Vivin","Howard","Iris");     
     //透過　stream4　產生一組Map  key 為字串長度　
     // vlaue為 一組list 存放相對應長度的字串
     Map<Integer,List<String>> myMap =  stream4.collect(
                Collectors.toMap((s)->s.length(), 
               (s)->{
                   List<String> list = new ArrayList();                  
                   list.add(s);
                    return list;
               } ,
               (oList,nList)->{oList.addAll(nList);
               return oList;
               }, TreeMap::new));     
     System.out.println(myMap);
     
     
    }
    
}
