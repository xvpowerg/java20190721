/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190922;

/**
 *
 * @author xvpow
 */
public class Skill {
   private int id;
   private String name;
   
   public Skill(int id,String name){
       this.id = id;
       this.name = name;               
   }
   public boolean equals(Object obj){
       if (obj == null || obj instanceof Skill == false){
           return false;
       }
       Skill tmpSkill = (Skill)obj;
       return id == tmpSkill.id && name.equals(tmpSkill.name);
   }
   
   public int hashCode(){
       return id + name.hashCode();
   }
   
   public String toString(){
       return name;
   }
}
