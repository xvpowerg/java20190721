/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20190804;

/**
 *
 * @author howard
 */
public class Ch3_2 {
    //需求如下 方法參數可以是 0~N
    //vargs
    static int sum(int... values){
        int sum = 0;
        for (int v :values){
            sum += v;
        }
      return sum;  
    }
    static int[] maxAndMin(int... values){
        int[]minMaxArray = { Integer.MAX_VALUE,
                            Integer.MIN_VALUE
                           };
        for (int v :  values){
            if (v  < minMaxArray[0]){
                minMaxArray[0] = v;
            }
            
            if(v > minMaxArray[1]){
                minMaxArray[1] = v;
            }            
        }
        if (values == null || values.length == 0){
            return null;
        }
        return minMaxArray;
    }
    
    static void  showMinMaxArray(int[] minMax){
         if (minMax != null){
          System.out.println("min:"+minMax[0]);
          System.out.println("max:"+minMax[1]);
      }else{
          System.out.println("無法比大小");
      }
    }
  //vargs 只能放在參數的最後面  以下程式碼這樣寫會錯!!!
//    static void test1(int... v1,String  v2){
//        
//    }
    public static void main(String[] args) {
       System.out.println(sum(5,2,3,7,2,5,1,3));
       
      int[] minMax =  maxAndMin(8,9,5,3,2,7);
      showMinMaxArray(minMax);
      int[] minMax2 =  maxAndMin(); 
      showMinMaxArray(minMax2);
       int[] values = {7,1,2,5,6,3};
       int[] minMax3 =  maxAndMin(values);
        showMinMaxArray(minMax3);
    }
    
}
