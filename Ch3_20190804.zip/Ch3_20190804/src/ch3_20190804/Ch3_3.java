/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20190804;

/**
 *
 * @author howard
 */
public class Ch3_3 {

    public static void main(String[] args) {
        //基本型型態打包
        /*
        byte   Byte
        short Short
        int  Integer
        long Long
        float Float
        double Double
        char Character
        boolean Boolean        
        */
        //手動打包 封箱 boxing
        int value= 10;
        Integer objInt = Integer.valueOf(value);        
        //如何打開包裹
        //解封箱 unboxing
        int myInt = objInt.intValue();
        
        int value2 = 20;
        //自動打包 自動封箱  auto boxing
        Integer objInt2 = value2;
        //自動開箱 自動解封箱 auto unboxing
        int myInt2 = objInt2;
        
        System.out.println(myInt2);
        
          Integer objInt3 = null;
          int v1 = objInt3+3;
          System.out.println(v1);
        
    }
    
}
