/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20190804;

/**
 *
 * @author howard
 */
public class PC {
    private String cpu;
    private int memory;
    int hd;
    String vidoCard;
    
    public PC(){
        
    }
    //Construct 建構子 建構式
    public PC(String inCpu,int inMemory){
        cpu = inCpu;
        memory = inMemory;
    }
    
    public void setCPU(String inCpu){
        if ( inCpu == null || inCpu.length() > 20 ){
            System.out.println("錯誤的CPU參數");
            return;
        }
        cpu = inCpu;
    }
    
    public String getCPU(){
        return cpu;
    }
    //領錢
    public int getMemory(){
        return memory;
    }
    //存錢
    public void setMemory(int inMemory){
        
        if (inMemory < 32){
            System.out.println("錯誤的Memory Size");
            return;
        }
        memory = inMemory;
    }
    void print(){
        System.out.println(cpu+":"+hd+":"+memory+":"+vidoCard);
    }
    //寫一個方法名為checkMemory 如果 Memory 大於32 回傳 true 小於 回傳 false
    boolean checkMomory(){
        return memory > 32;
    }
    
    
}
