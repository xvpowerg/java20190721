/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20190804;

import java.util.Scanner;

public class Ch3_5 {

    public static void main(String[] args) {
//        Scanner scan = new Scanner(System.in);
//        System.out.println("請輸入您的年齡:");
//        String ageStr = scan.next();
//        int age = Integer.parseInt(ageStr);//把字串轉整數
//        if (age >= 18){
//            System.out.println("成年:"+age);
//        }else{
//            System.out.println("未成年:"+age);
//        }
//        String value = "1234";
//        Integer.parseInt(value);
    String binary1 = Integer.toBinaryString(527);//二進位
    String octStr2 =  Integer.toOctalString(527);//八進位
    String hexStr3 = Integer.toHexString(527);//16進位
    System.out.println(binary1);
    System.out.println(octStr2);
    System.out.println(hexStr3);
    }

}
