/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20190804;

/**
 *
 * @author howard
 */
public class Ch3_10 {
    public static void main(String[] args) {
       //類別 
        //規格 特徵集合
        //PC特徵
        //CPU
        //記憶體
        //硬碟
        //顯示卡
        
       //物件
        PC p1 = new PC();
        p1.setCPU(null);
        p1.hd = 20000;
        p1.setMemory(512);
        p1.vidoCard = "3038 super";
        System.out.println(p1.checkMomory());
        p1.print();
        
        PC p2 = new PC();
        p2.setCPU("AMD 2600");
        p2.hd = 10000;
        p2.setMemory(32);
        p2.vidoCard = "1070";
          System.out.println(p2.checkMomory());
        p2.print();
        
        
        PC p3 = new PC("Intel 10 i7",64);
        p3.print();
        
    }
    
}
