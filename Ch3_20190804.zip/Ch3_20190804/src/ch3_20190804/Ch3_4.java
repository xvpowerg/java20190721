package ch3_20190804;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author howard
 */
public class Ch3_4 {

    public static void main(String[] args) {
        int value1 = 128;
        int value2 = 128;
        System.out.println(value1 == value2);
        Integer obJInt1 = value1;
        Integer obJInt2 = value2;
        System.out.println(obJInt1 == obJInt2);
        //valueOf 有cach 
        //如果我們數字如果落在1各byte區間，那麼就會使用快取建構封箱
        int value3 = 128;
        int value4 = 128;
        System.out.println(value3 == value4);
        Integer obJInt3 = value3;
        Integer obJInt4 = value4;
        System.out.println(obJInt3.equals(obJInt4));
    }

}
