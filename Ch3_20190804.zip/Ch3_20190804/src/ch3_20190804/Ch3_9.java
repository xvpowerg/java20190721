/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20190804;
public class Ch3_9 {

    
    //如果有一個方法 做絕對值
    //參數必須支持 整數 跟 浮點數
    static int abs(int value){
        return value > 0 ?value:value *-1;
    }
     static float abs(float value){
        return value > 0 ?value:value *-1;
    }
    
     static void test7(byte b1){
         System.out.println("b1");
     }
     static void test7(Float f1){
         System.out.println("Float");
     }
     
    public static void main(String[] args) {
        //Float f = Integer.valueOf(25);
        int v1 = 10;
        float f2 = v1;
            //    test7(1);
    }
    
}
