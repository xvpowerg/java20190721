/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20190804;

/**
 *
 * @author howard
 */
public class Ch3_8 {
    /* 多載順序
    1 先找一樣的
    2 在相同類型可相容的
    3 再找不同類型可相容
    4 轉成封箱類型    
    */
    static void test1(int v1){
        System.out.println("test1 int");
    }
    static void test1(float v1){
        System.out.println("test1 float");
    }
    static void test2(byte b1){
        System.out.println("test2 byte");
    }
    static void test2(float b1){
        System.out.println("test2 float");
    }
    
    static void test3(byte b1){
        System.out.println("test3 byte");
    }
//      static void test3(long b1){
//        System.out.println("test3 long");
//    }
//      static void test3(float v2){
//        System.out.println("test3 float");
//    }
    static void test3(Integer intObj){
        System.out.println("test3 Integer");
    }
    
    static void test4(int v1,float v2){
        System.out.println("int float");
    }
    
    static void test4(int v1,int v2){
        System.out.println("int int");
    }
    
   static void test5(int v1,float v2){
        System.out.println("int float");
    }
    
    static void test5(Integer v1,int v2){
        System.out.println("Integer int");
    }
    
    static void test6(int v1,byte v2){
        System.out.println("int byte");
    }
    
    static void test6(Integer v1,int v2){
        System.out.println("Integer int");
    }
    
  static void test7(int v1,Integer v2){
        System.out.println("int Integer");
    }
    
    static void test7(Integer v1,int v2){
        System.out.println("Integer int");
    }
        
     static void test8(int v1,Integer v2,float f1){
        System.out.println("int Integer float");
    }
    
    static void test8(Integer v1,int v2,int v3){
        System.out.println("Integer int int");
    }
    
    static void test9(int v1,float f1,Integer v2){
        System.out.println("int  float Integer");
    }
    
    static void test9(int v2,Integer v1,int v3){
        System.out.println("Integer int int");
    }
    
    public static void main(String[] args) {
//        test1(7);
//        test1(10.5f);
//        //7是一個整數預設為Integer 
//        test2(7);
//        test3(5);
        test4(5,8);
        test5(3,6);
        test6(12,7);
        
        //test7(1,6);
       // test8(1,2,3);
       // test9(1,2,3);
    }
    
}
