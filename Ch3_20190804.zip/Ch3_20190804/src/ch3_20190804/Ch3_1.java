/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20190804;
public class Ch3_1 {
    
     static void swap(int a,int b){
        int tmp = a;
        a = b;
        b = tmp;
     }
     static void swapArray(int[] array){
          int tmp2 = array[0];
         array[0] = array[1] ;
         array[1] = tmp2;       
     }
     
      static void swapString(String st1,String st2){
          String tmp = st1;
          st1 = st2;
          st2 = tmp;
      }
    public static void main(String[] args) {        
        //call By Value
        //當變數放在方法內時，無論如何都不會改變傳入的變數
        //所有基本型態都是call by value        
        int a = 10;
        int b = 20;
        swap(a,b);
        System.out.println(a+":"+b);
        //Call by Reference
        //所有非基本型態都是Call by Reference
        //當變數放在方法內時，可能會改變傳入的變數
         int[] array = {15,26};
         swapArray(array);
         System.out.println(array[0]+":"+array[1]);   
         
        String st1 = "A";
        String st2 = "B";
       swapString(st1,st2);
       System.out.println(st1+":"+st2);
    }
    
}
