/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20190804;


public class Ch3_7 {
    //多載口訣 overloding 
    //方法名稱要一樣 參數的數量或類型不一樣
    static int sum(int v1,int v2){
        return v1 + v2;
    }
    static float sum(int v1,int v2,float v3){
        return v1+v2+v3;
    }
    
    public static void main(String[] args) {
        System.out.println(sum(1,2));
        System.out.println(sum(1,2));
        System.out.println(sum(1,2,2.5f));        
    }
    
}
