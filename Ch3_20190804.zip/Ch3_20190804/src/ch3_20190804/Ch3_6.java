/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20190804;

/**
 *
 * @author howard
 */
public class Ch3_6 {

   
    public static void main(String[] args) {
        String isOpen = "tRue";
        //只要是true不分大小寫一律轉換為true
        //只要不是true就轉換為false
        Boolean b1 =  Boolean.parseBoolean(isOpen);
       System.out.println(b1.booleanValue());
        char case1 =  Character.toLowerCase('A');
        System.out.println(case1);      
 //isAlphabetic 是不是英文字母
      boolean isAlpha= Character.isAlphabetic('b');
      //isDigit 是不是數字
      boolean isDigit= Character.isDigit('5');
      System.out.println(isAlpha);
      System.out.println(isDigit);
     boolean isAlpha2= Character.isAlphabetic('6');
      boolean isDigit2= Character.isDigit('c');
      System.out.println(isAlpha2);
      System.out.println(isDigit2);
    }
    
}
