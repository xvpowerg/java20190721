/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190825;

import java.util.Iterator;

/**
 *
 * @author shihhaochiu
 */

class MyIntIterators implements java.util.Iterator<Integer>{
    private MyIntArray array = null;
    private int index = -1;
    public MyIntIterators(MyIntArray array){
        this.array = array;
    }
    public boolean hasNext(){
        
        return index < array.size - 1;
    }
    public Integer next(){
        return array.getInt(++index);
    }
}


public class MyIntArray extends MyStringArray implements MyIterable {
    private int[] array;
    public MyIntArray(int index){
        super(index);
         array = new int[this.size];
    }
    public void addInt(int index,int value){
        array[index] = value;
    }
    public int getInt(int index){
        return array[index];
    }
      public Iterator iterator(){
          return new MyIntIterators(this);
      }
    
}
