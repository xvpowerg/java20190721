/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190825;
import java.util.Random;
/**
 *
 * @author shihhaochiu
 */
public class Ch6_2 {

        static void putUSB(USB usb){
            Random ran = new Random();
//            usb.write(ran.nextInt(10000)+"");
            usb.write(null);
            usb.check();
            System.out.println(usb.read());
        }
    public static void main(String[] args) {
        
        Ｏwl owl = new Ｏwl();
        owl.flying(20);
        
        Dragon dg = new Dragon();
        Fly f1 = dg;
        Spitfire sf = dg;
        
        f1.flying(100);
        sf.spraying();
        
        USBHD usbhd = new USBHD();
        //usbhd.MAX_SPEED =10;
        putUSB(usbhd);
        
    }
    
}
