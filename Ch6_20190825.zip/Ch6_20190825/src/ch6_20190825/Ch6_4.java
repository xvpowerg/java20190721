/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190825;
import java.util.function.Consumer;

 class StyleConsumer implements Consumer{
    public void accept(Object obj){
        System.out.println("資訊:"+obj);
    }
} 


public class Ch6_4 {

    static  void print(MyIterable it){
        //it.forEach(new StyleConsumer());
        it.forEach();
    }
    
    public static void main(String[] args) {
       
//        MyStringArray array  =new MyStringArray(5);
//        array.add(0,"Howard");
//        array.add(1,"Ken");
//        array.add(2,"Lindy");
//        array.add(3,"Vivin");
//        array.add(4,"Join");
        MyIntArray array = new MyIntArray(5);
        array.addInt(0, 10);
        array.addInt(1, 32);
        array.addInt(2, 71);
        array.addInt(3, 85);
       
        print(array);
//        for (int i =0; i < array.size;i++){
//            System.out.println(array.get(i));
//        }
        //1 顯示的動作
        //2 get 或 add 的index發生錯時 要拋出
       // new IllegalArgumentException("索引大於4");
    }
    
}
