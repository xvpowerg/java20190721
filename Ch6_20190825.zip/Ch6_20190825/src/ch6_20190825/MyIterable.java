/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190825;
import java.util.Iterator;
import java.util.function.Consumer;
/**
 *
 * @author shihhaochiu
 */
public interface MyIterable {
    default void forEach(Consumer counsumer){
        Iterator it = iterator();
        while(it.hasNext()){
            if (counsumer == null){
                  System.out.println(it.next());
            }else{
                counsumer.accept(it.next());
            }
          
        }
    }
     default void forEach(){
         forEach(null);
     }
    public Iterator iterator();
}
