/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190825;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.IOException;
import java.util.List;
/**
 *
 * @author shihhaochiu
 */
public abstract class MyErp {
    private  List<String> readData(){
        
       String pathStr =  "/Users/shihhaochiu/javadir/reportData.txt";
       
       Path path = Paths.get(pathStr);
        List<String> datas = null;
       try{
           datas =  Files.readAllLines(path);   
       }catch(IOException ex){
           System.out.println(ex);
       }
     
        return datas;
    }
    public void exportReport(){
       List<String> data =  readData();
       reportStyle(data);
    }
    protected abstract void reportStyle(List<String> data);
    
    
}
