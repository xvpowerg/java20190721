/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190825;

/**
 *
 * @author shihhaochiu
 */
public class IronMan implements IronManGroup  {
    public void jumping(){
       System.out.println("Iron Jump");
    }
     public void walking(){
       System.out.println("Iron walking");
    }
      public void flying(float speed){
       System.out.println("Iron flying:"+speed);
    }
         public void spraying(){
       System.out.println("Iron spraying");
    }
}
