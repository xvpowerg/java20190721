/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190825;

/**
 *
 * @author shihhaochiu
 */
@FunctionalInterface
public interface Test1 {
    void t();
    default void myDefault(){
        System.out.println("Test1!");
    }
}
