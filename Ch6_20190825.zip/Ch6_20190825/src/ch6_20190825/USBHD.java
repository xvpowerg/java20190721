/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190825;

/**
 *
 * @author shihhaochiu
 */
public class USBHD implements USB {
    
    private String data;
    public void write(String value){
        data = value;
    }
    
    public String read(){
        return data;
    }
}
