/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190825;

/**
 *
 * @author shihhaochiu
 */
public interface USB {
    //預設為public static final 
    int MAX_SPEED = 54;
    void write(String value);
    String read();
    public default void check(){
        if (read() == null){
           throw new IllegalStateException("資料讀取有誤!");
        }
    }
    
}
