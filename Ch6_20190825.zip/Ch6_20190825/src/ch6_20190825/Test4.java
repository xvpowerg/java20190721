/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190825;

/**
 *
 * @author shihhaochiu
 */
public interface Test4 {
    //靜態方法不會被繼承
    static int max(int a,int b){
        return a > b?a:b;
    }
}
