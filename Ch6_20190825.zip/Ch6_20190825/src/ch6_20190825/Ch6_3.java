/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190825;

/**
 *
 * @author shihhaochiu
 */
public class Ch6_3 implements Test3 {
        public void t(){
            
        }
    public static void main(String[] args){
        Ch6_3 c63 = new Ch6_3();
        c63.myDefault();
        //System.out.print(args);
        
       String[] array = {"A","B","C"};
       for (String v : array){
           System.out.println(v);
       }
    }
}
