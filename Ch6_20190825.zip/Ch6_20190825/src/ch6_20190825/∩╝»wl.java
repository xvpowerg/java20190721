/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190825;

/**
 *
 * @author shihhaochiu
 */
public class Ｏwl implements Fly {
    public void flying(float speed){
        System.out.println("時速:"+speed);
    }
}
