/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190825;

/**
 *
 * @author shihhaochiu
 */
@FunctionalInterface
//介面的一般方法都是抽象的
public interface Fly {
    //預設抽象方法都是public 
    public abstract void flying(float speed);
    
}
