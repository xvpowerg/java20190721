/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190825;

/**
 *
 * @author shihhaochiu
 */

public interface IronManGroup extends Fly,Jump,Walk,Spitfire {
    
}
//介面
//希望有一個協定稱為USB
//有兩個方法
//1 write 寫入String value
//2 read  回傳一筆String

//USBHD的類別
//write 寫入的value
//read 讀出上一步的value
