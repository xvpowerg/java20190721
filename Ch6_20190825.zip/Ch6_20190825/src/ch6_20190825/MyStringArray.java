/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190825;
import java.util.Iterator;

/**
 *
 * @author shihhaochiu
 */

class MySAIterator implements Iterator<String>{
    private MyStringArray array;
    private int index = -1;
    public MySAIterator(MyStringArray array){
        this.array = array;
        
    }
    public boolean hasNext(){
        return index < array.size - 1;
    }
    public String next(){
        return array.get(++index);
    }
}

public class MyStringArray implements MyIterable {
    public final int size;
    private String[] array;
    private void verifyIndex(int indexs){
        if (indexs >= size   ){
            throw 
           new IllegalArgumentException("索引不可大於:"+(size-1));
        }
    }
    public MyStringArray(int size){
        this.size = size;
        array = new String[size];
    }
    public void add(int index,String value){
        
        verifyIndex(index);
        array[index] = value;
    }
    public String get(int index){
         verifyIndex(index);
        return array[index];
    }
    
    public Iterator iterator(){
        return new MySAIterator(this);
    }
}
