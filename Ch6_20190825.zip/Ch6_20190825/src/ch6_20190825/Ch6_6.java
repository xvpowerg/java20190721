/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190825;

/**
 *
 * @author shihhaochiu
 */
public class Ch6_6 {

   private class InnerClass{
        private String name;
        private int count;
        public InnerClass(String name,int count){
            this.name = name;
            this.count = count;
        }
        public String getName(){
            return name;
        }
        public int getCount(){
            return count;
        }
        
        public String toString(){
            return this.getName()+":"+this.getCount();
        }
    }
    
   public void test1(){
        InnerClass inclass = new InnerClass("A",10);
   }
    
    public static void main(String[] args) {
        // TODO code application logic here
       Ch6_6 c66 = new Ch6_6();
       Ch6_6.InnerClass innc = c66.new InnerClass("Vivin",10);
       System.out.println(innc);
    }
    
}
