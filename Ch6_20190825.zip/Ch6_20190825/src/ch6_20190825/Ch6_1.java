/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190825;

import java.util.List;

/**
 *
 * @author shihhaochiu
 */
public class Ch6_1 extends MyErp{
 protected  void reportStyle(List<String> data){
     System.out.println(data);
 }
    /**
     * @param args the command line arguments
//     */
//    public static void main(String[] args) {
//        
//        Ch6_1 ch61 = new Ch6_1();
//        ch61.exportReport();
//        
//    }
//    
}
