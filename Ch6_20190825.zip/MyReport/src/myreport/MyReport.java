/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myreport;
import ch6_20190825.MyErp;
import java.util.List;
/**
 *
 * @author shihhaochiu
 */
public class MyReport  extends MyErp{

    protected void reportStyle(List<String> data){
        data.forEach( (str)->{
           String[] dataArray = str.split(",");
          String report =  String.format("員工:%s 第1季達成率:%s%% 第2季達成率:%s%% "
                   + "第3季達成率:%s%% 第4季達成率:%s%%", 
                   dataArray[0],dataArray[1],dataArray[2],dataArray[3],dataArray[4]);
           System.out.println(report);
        
        });
        
        
    }
    
    public static void main(String[] args) {
        MyReport myReport = new MyReport();
        myReport.exportReport();
    }
   
    
}
