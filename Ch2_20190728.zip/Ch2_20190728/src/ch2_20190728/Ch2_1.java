/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20190728;
import java.util.Arrays;
public class Ch2_1 {
    public static void main(String[] args) {
      int[] numbers = new int[5];
      numbers[0] = 71;
      numbers[1] = 83;
      numbers[2] = 96;
      numbers[3] = 42;
      numbers[4] = 51;
      
      for (int i = 0;i<numbers.length ;i++){
          System.out.printf("index:%d value:%d ",i,numbers[i]);
      }
      System.out.println();
      System.out.println("=============================");
      //for each 
      for (int number : numbers){
          System.out.print(number+" ");
      }
      System.out.println();
      System.out.println("=============================");
      //lambda 語法跑foreach
      Arrays.stream(numbers).forEach(System.out::println);
      
    }
    
}
