/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20190728;

/**
 *
 * @author howard
 */
import java.util.Arrays;
public class Ch2_6 {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //小寫 > 大寫 > 數字
        
        String[] strArray = {"Gij","kbi","AdvZXYAAJKH","m3c","kci","2Zj","G2Z"};
        Arrays.sort(strArray);
        for (String str : strArray){
            System.out.print(str+" ");
        }
        System.out.println();
          System.out.println("===========================");
       int index =  Arrays.binarySearch(strArray, "Gij");
       System.out.println(index);
      index =  Arrays.binarySearch(strArray, "mzz");
          System.out.println(index);
      index =  Arrays.binarySearch(strArray, "2Az");
          System.out.println(index);    
         index =  Arrays.binarySearch(strArray, "Cdek");
            System.out.println(index);    
            index =  Arrays.binarySearch(strArray, "kxi");   
            System.out.println(index);    
    }
    
}
