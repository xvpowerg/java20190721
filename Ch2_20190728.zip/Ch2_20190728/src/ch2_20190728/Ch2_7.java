/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20190728;

/**
 *
 * @author howard
 */
public class Ch2_7 {

 
    public static void main(String[] args) {
     int[][] array2x3 = new int[2][3];
     array2x3[0][0] = 35;
     array2x3[0][1] = 72;
     array2x3[0][2] = 61;
     array2x3[1][0] = 47;
     array2x3[1][1] = 53;
     array2x3[1][2] = 26;

     for (int i =0 ; i< array2x3.length; i++){
         for (int k = 0;k <array2x3[i].length;k++){             
              System.out.print(array2x3[i][k]+" ");
         }
            System.out.println();
     }
        
     
     for (int[] array2 : array2x3){
         
         for (int value : array2){
             System.out.print(value+" ");
         }
           System.out.println();
     }
        
        
    }
    
}
