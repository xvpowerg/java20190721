/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20190728;
import java.util.Arrays;
/**
 *
 * @author howard
 */
public class Ch2_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          int lenght = 60000;  
         int[] data1 = new int[lenght];
        for (int i = 0; i<data1.length;i++){
            data1[i]= i;
        }
        
        //搜尋
        int find = lenght -1;
        double start = System.nanoTime();
        
        for (int index = 0; index < data1.length;index++){
            if (data1[index] == find){
                System.out.printf("您要找的%d ,index為:%d%n",find,index);
                break;
            }else if(index == data1.length - 1){
                System.out.printf("您要找的%d ,無法搜尋",find);
            }            
        }
         double end = System.nanoTime();
        System.out.println( (end -start) / 1_000_000);
         System.out.println("==================================="); 
         
        start = System.nanoTime();
        int index = Arrays.binarySearch(data1, find);
        System.out.printf("二分搜尋法 您要找的%d ,index為:%d%n",find,index); 
        end = System.nanoTime();
        System.out.println( (end -start) / 1_000_000);
    }
    
}
