/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20190728;

/**
 *
 * @author howard
 */
public class Ch2_2 {

    public static void main(String[] args) {
        int[] array1 = new int[5];
        int array2[] = new int[5];
        int[] array3 = {6,7,8,9};//長度等於4 每個數值都給了初始值
        int[] array3Empty = {};//空陣列
        int[] array4 = new int[]{1,2,6,7}; //用於已宣告後重新給數值        
        //array3 = {6,7,8,9,10,11,12,13};//Erro!!
        array3 = new int[]{6,7,8,9,10,11,12,13};
        
        //搜尋
        int[] data1 = {1,9,8,35,71,21,16};
        int find = 8;
        for (int index = 0; index < data1.length;index++){
            if (data1[index] == find){
                System.out.printf("您要找的%d ,index為:%d%n",find,index);
                break;
            }else if(index == data1.length - 1){
                System.out.printf("您要找的%d ,無法搜尋",find);
            }            
        }
        
        
    }
    
}
