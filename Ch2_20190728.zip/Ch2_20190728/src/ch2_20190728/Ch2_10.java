/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20190728;

/**
 *
 * @author howard
 */
public class Ch2_10 {
     
    static void test1(int count){
        if (count <= 3){
            System.out.println(count);
            test1(count + 1);            
        }
        System.out.println(count);
    }
    static int factorial(int n){
        if (n <= 1){
            return 1;
        }
        return factorial(n-1) * n;
    }
    
    public static void main(String[] args) {
        int[] array = {8,9,1,2,5,6,7};
        qSort(array,0,array.length-1);
        for (int v :array){
            System.out.print(v+" ");
        }
    }
    
    static void swap(int[] array,int index1,int index2){
        int tmp = array[index1];
        array[index1] = array[index2];
        array[index2] = tmp;
    }
    static int pivot(int[] value,int start,int end){
        int cmp = value[start];
        int pivot = start;
        for (int i =start;i<=end;i++){
            if (cmp > value[i]){
                pivot++;
               swap(value,pivot,i);  
            }            
        }
        swap(value,pivot,start);  
        return pivot;
    }
    
    static void qSort(int[] value,int start,int end){
        if (start < end){
            int pivot =  pivot(value,start,end);
            qSort(value,start,pivot-1);
            qSort(value,pivot+1,end);
        }
    }
    
}
