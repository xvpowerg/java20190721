/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20190728;
import java.util.Arrays;
public class Ch2_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] values = {18,8,10,5,2};
        Arrays.sort(values);
       //2 5 8 10 18
        int index = Arrays.binarySearch(values, 18);
        System.out.println(index);
        //找不到有三種可能性
        //1 比所有都小 回傳-1
           index = Arrays.binarySearch(values,0);
           System.out.println(index);
        //2 比所有都大 
          index = Arrays.binarySearch(values,25);//(陣列長度+1) * -1
          System.out.println(index);
        //3 在數字之間
        index = Arrays.binarySearch(values, 15);//(被找數的下一個數字的長度 ) * -1
           System.out.println(index);
        
           
           
        
    }
    
}
