/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20190728;

/**
 *
 * @author howard
 */
public class Ch2_9 {
    
  static void test1(){
        System.out.println("Test1...");
    }
  
  static int test2(int v1,int v2){
    int m = v1 - v2;
    return m;//1 回傳數值 2 離開方法    
  }
  
  static int pow(int n,int p){
      int result = 1;
      for (int i =1;i <= p;i++){
          result *= n;
      }
      return result;
  }
  
  
    //static 之能呼叫 static 的
    public static void main(String[] args) {       
        test1();    
       int ans =  test2(71,25);
       System.out.println(ans);
       
        System.out.println(pow(3,3));
       
    }
    
}
