/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20190728;

/**
 *
 * @author howard
 */
public class Ch2_8 {

    public static void main(String[] args) {
        int[][] array1 = new int[2][3];
        int[] array2[] = new int[2][3];
        int[][] array3[] = new int[2][3][];
        
        int[][] array4 = new int[3][];
        array4[0] = new int[10];
        array4[1] = new int[2];
        array4[2] = new int[5];
        
        int[][][] array5 = new int[3][][];
        array5[0] = new int[2][];
        array5[0][0] = new int[3];
        array5[0][1] = new int[8];
        
         int[][] array6 = {{50,21,71  },
                           {32,84,10,25  }   };
        
        int[][][] array7 = { { {6,8,9},
                               {7,1} 
                              },               
                               { {5,3,2,4},
                                 {19}
                               }  
                           }; 
          System.out.println(array7[0][0][2]);
          System.out.println(array7[1][1][0]);
        
          int[][] array8 = new int[3][];   
          array8[0] = new int[5];
          array8[1] = new int[3];
          array8[0][2] = 10;
          //array8[1][3] = 71;//java.lang.ArrayIndexOutOfBoundsException
          array8[2][1] = 41;//NullPointerException
          
          
          
          
    }
    
}
