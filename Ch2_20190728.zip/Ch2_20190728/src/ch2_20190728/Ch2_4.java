/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20190728;
import java.util.Random;
import java.util.Arrays;
/**
 *
 * @author howard
 */
public class Ch2_4 {

    public static void main(String[] args) {
        Random random = new Random();
        int length = 150;
          //int[] array = {8,9,1,2,5,6,7,4};  
          int[] array = new int[length];  
          for (int i =0; i< length;i++){
              array[i] = random.nextInt(length+100);
          }
          double start = System.nanoTime();
          
          //目標由小到大排序
          for (int i =0; i < array.length;i++){
              for (int k = i +1;k < array.length;k++){
                  if (array[i] > array[k]){
                      int tmp = array[i];
                      array[i] = array[k];
                      array[k] = tmp;
                  }                  
              }              
          }
          
          double end = System.nanoTime();
          System.out.println( (end -start) / 1_000_000);
         System.out.println("=====================");
         
         start = System.nanoTime();
          Arrays.sort(array);//資料量大時
        end = System.nanoTime();
       System.out.println( "QSort:"+(end -start) / 1_000_000);  
          
//          for (int v : array){
//              System.out.print(v+" ");
//          }
            
        
        
    }
    
}

