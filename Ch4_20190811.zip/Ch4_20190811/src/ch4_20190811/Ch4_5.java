/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190811;
import static ch4_20190811.Employee.SUM;
public class Ch4_5 {
      public static void main(String[] args) {
          Employee emp1 = new Employee();
          emp1.publlicMethod();
          emp1.protectedMethod();
          emp1.defaultMethod();   
          
          SUM(2, 5);
      }
      
}
