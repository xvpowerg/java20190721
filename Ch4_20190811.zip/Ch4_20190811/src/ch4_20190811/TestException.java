package ch4_20190811;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
public class TestException {
    public void TestException(boolean throwEx,String msg)
            throws IOException,SQLException,FileNotFoundException{
        if (throwEx){
            //throw new IOException();
            throw new FileNotFoundException(msg);
        }else{
            throw new SQLException(msg);
        }
        
    }
    
    public void TestException2(boolean throwEx,String msg){
        if (throwEx){
            throw new NullPointerException(msg);
        }
        
    }
    
}
