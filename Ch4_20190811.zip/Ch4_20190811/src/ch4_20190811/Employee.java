/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190811;

/**
 *
 * @author howard
 */
public class Employee {
    private float salary;
    //salary 不可低於23000
    //salary 不可高於200000
    public void setSalary(float salary){
        if (salary < 23000 || salary > 200000){
            System.out.println("錯誤的薪資");
           throw new IllegalArgumentException("錯誤的薪資!");
        }
        this.salary = salary;
    }
    
    public float getSalary(){
        return salary;
    }
    
    public static int  SUM(int a,int b){
        System.out.println(a +b);
        return a +b;
    }
    
    public void publlicMethod(){
        System.out.println("Employee public");
    }
    protected void protectedMethod(){
        System.out.println("Employee protected");
    }
    void defaultMethod(){
        System.out.println("Employee default");
    }    
    private void privateMethod(){
        System.out.println("Employee private");
    }
}
