/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190811;

public class Test1 {
//    Test1(){
//      //  this("vivin",10,75.6f);
//        System.out.println(" Test1()");
//    }
    Test1(int v1,float f2){
     //  this(); 
       System.out.println(" Test1(int float)");
    }
    
    Test1(String name,int v1,float f2){
        System.out.println(" Test1(String int float)");
    }
}
