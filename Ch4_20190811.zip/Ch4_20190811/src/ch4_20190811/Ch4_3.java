/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190811;

/**
 *
 * @author howard
 */
public class Ch4_3 {
    static void printAnimal(Animal animal){
        animal.print();
    }
    static void printAnimal(Animal... animals){
        
        for (Animal anim : animals ){
            anim.print();
        }
    }
    public static void main(String[] args) {
      Dog dog2 = new Dog("FeFe",15);
      dog2.addFoods("雞肉");
      dog2.addFoods("香蕉");
      dog2.print();
      
      Cat cat2 = new Cat("MeNi",16);  
      cat2.addFoods("魚");
      cat2.addFoods("毛線");
      cat2.print();
      
     Cat cat3 = new Cat("Kitty",25);  
      cat3.addFoods("飯糰");
      cat3.addFoods("漢堡");
     
      
      //多型 polymorphic 
      Animal a1 = cat2;
      a1.print();
      Animal a2 = dog2;
      a2.print();
      
      printAnimal(cat2);
      printAnimal(dog2);
       printAnimal(dog2,cat2,cat3);
      //coupling
      //低耦合 高聚合
    }
    
}
