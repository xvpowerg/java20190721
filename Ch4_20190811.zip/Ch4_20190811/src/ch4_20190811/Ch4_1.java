/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190811;

/**
 *
 * @author howard
 */
public class Ch4_1 {
    public static void main(String[] args) {
        
        Student st1 = new Student();
        st1.setName("Ken");
        st1.setAge(10);
        st1.setScore(75);
        System.out.println(st1.getName());
        System.out.println(st1.getScore());
        System.out.println(st1.getAge());
         Student st2 = new Student("Vivin",18,71);
         st2.print();
         //1  提供一組方法 可印出Name Age Score 的內容 並且顯示 是否Pass 或  Fail
         //Pass就是 成績大於等於60
         //Pass就是 成績小於60
        Student st3 = new Student();   
        st3.print();
    }
    
}
