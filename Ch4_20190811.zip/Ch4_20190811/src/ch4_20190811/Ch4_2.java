/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190811;

/**
 *
 * @author howard
 */
public class Ch4_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       // Test1 t1 = new Test1(1,25.6f);
//       Dog dog = new Dog();
//       dog.setHeight(10);
//       dog.setName("Nono");
//       dog.addFoods("肉");
//       dog.addFoods("雞蛋糕");
//       dog.print();
//       //希望寫一個print 方法 印出 名稱: 身高 喜歡的食物
//       Cat cat1 = new Cat();
//       cat1.setHeight(12);
//       cat1.setName("加菲");
//       cat1.addFoods("義大利肉丸");
//       cat1.addFoods("千層麵");
//       cat1.print();
//       
      Dog dog2 = new Dog("FeFe",15);
      dog2.addFoods("雞肉");
      dog2.addFoods("香蕉");
      dog2.print();
      
      Cat cat2 = new Cat("MeNi",16);  
      cat2.addFoods("魚");
      cat2.addFoods("毛線");
      cat2.print();
               
    }
    
}
