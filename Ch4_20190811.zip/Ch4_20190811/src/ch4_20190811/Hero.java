/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190811;


public class Hero {
    public void printHero(){
        System.out.println("ch4_20190811 Hero");
    }
}
