/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190811;

public class Animal {
   private String name;
   private float height;
   private String[] favoritFoods = new String[5];
   private int index = -1;
   public Animal(){       
   }
   public Animal(String name,float height){
       this.name = name;
       this.height = height;
   }
   public void addFoods(String food){
       favoritFoods[++index] = food;
   }
   public String getName(){
       return name;
   }
   public void setName(String name){
       this.name = name;
   }
   public float getHeight(){
       return height;
   }
   public void setHeight(float height){
       this.height = height;
   }
       
   public void print(){
      System.out.print("name:"+name+" height:"+height+" foods:");
      for (int i =0; i <= index;i++){
          System.out.print(favoritFoods[i]+" ");
      }
          System.out.println();
   }
}
