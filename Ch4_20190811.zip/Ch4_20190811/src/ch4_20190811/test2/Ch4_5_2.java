/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190811.test2;
import ch4_20190811.Employee;
import ch4_20190811.Hero;
import static ch4_20190811.Employee.SUM;
public class Ch4_5_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//       Employee emp2 = new Employee();
//        emp2.publlicMethod();
//        
//        Hero hero = new Hero();
//        hero.printHero();
//        
//        ch4_20190811.test2.Hero hero1 = new   ch4_20190811.test2.Hero ();
//        hero1.showHero();
        
        System.out.println(SUM(2, 5));
        
    }
    
}
