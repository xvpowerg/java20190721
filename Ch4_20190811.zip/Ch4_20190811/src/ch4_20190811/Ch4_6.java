/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190811;

/**
 *
 * @author howard
 */
public class Ch4_6 {

   //例外分2種
    //1 必要例外檢測
       //一定需要try catch
    //2 非必要例外檢測
       //不一定需要try catch
    public static void main(String[] args) {
       
        Employee emp = new Employee();
       try{
             emp.setSalary(15000);
            System.out.println("......"+emp.getSalary());  
       }catch(IllegalArgumentException ex){
           System.out.println(ex);
       }
    
        
        
    }
    
}
