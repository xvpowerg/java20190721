/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190811;
import java.io.IOException;
import java.sql.SQLException;
import java.io.FileNotFoundException;
/**
 *
 * @author howard
 */
public class Ch4_7 {

    public static void main(String[] args) {
      
        TestException tex = new TestException();        
        tex.TestException2(true, "不可為null");
        
//        try{
//             tex.TestException(false,"測試錯誤訊息");
//        }catch(SQLException ex){
//            System.out.println(ex.getMessage());
//            ex.iterator().forEachRemaining((t)->System.out.println(t));
//           StackTraceElement[]  stes =  ex.getStackTrace();
//           for (StackTraceElement ste :stes){
//               System.out.println(ste);
//           }
//        }catch(FileNotFoundException ex){
//            System.out.println(ex);
//        }catch(IOException ex){
//            System.out.println(ex);
//        }
     
        
    }
    
}
