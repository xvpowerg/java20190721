/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190811;

public class Student {
   private String name;
   private int age;
   private float score;
   // this() 只可在建構子內呼叫 他可呼叫目前類別其他建構子
   // this() 位置只能是目前建構子的第一行命令 
    Student(){
       //this.name = "Empty";
       this("Empty",0,0);
   }
   //this for Object
   Student(String name,int age,float score){
       this.name = name;
       this.age = age;
       this.score = score;
   }
   public void setName(String name){
       this.name = name;
   }
   public String getName(){
       return name;
   }
    
   public void setAge(int age){
       this.age = age;
   }
   public int getAge(){
       return age;
   }
   
   public void setScore(float score){
       this.score = score;
   }
   public float getScore(){
       return this.score;
   }
   public boolean isPass(){
       return score >= 60;
   }
   public void print(){
       String passMsg = isPass()?"Pass":"Faill";
       System.out.println(name+":"+age+":"+score+":"+passMsg);
   }
}
