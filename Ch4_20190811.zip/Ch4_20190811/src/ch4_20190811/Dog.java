/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190811;

/**
 *
 * @author howard
 */
//繼承
//java 類別的繼承只能單一繼承
//可繼承大部分的方法與屬性
//以下不會被繼承
//1 私有的所有方法與屬性
//2 建構子Constructor
//3 default的讀取權限 在不同packag不會被繼承
public class Dog extends Animal{
    Dog(){
        
    }
    
    Dog(String name,int height){
//        this.setName(name);
//        this.setHeight(height);
//super() 呼叫父類別的建構子
//super() 必須為建構子的第一行命令
            super(name,height);
    }
    
    public void print(){
        System.out.print("狗狗:");
        // super 呼叫父類別的print
        super.print();
    }
    
    
}
