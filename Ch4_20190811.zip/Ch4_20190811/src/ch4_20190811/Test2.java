/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190811;

/**
 *
 * @author howard
 */
public class Test2  extends Test1{
    //以下為預設建構子
    //所有建構子在預設情況下都會呼叫super
    public Test2(){
        super(1,5.3f);        
    }
}
